#!/usr/bin/env bash

# Объявить переменные
TASKID=16 #вариант
VAR_1=$(wc -l < dns-tunneling.log | awk '{print $1}')


echo $VAR_1

awk -F'\t' '$12 == 3 {print $5}' dns-tunneling.log | sort -n -t . -k 1,1 -k 2,2 -k 3,3 -k 4,4 | uniq -c | awk '{print $2 "\t" $1}' | sort -k2,2nr -s > results.txt

VAR_2=$(wc -l < results.txt)
echo "VAR_2: $VAR_2"


# Вывод значений переменных
# echo "TASKID is $TASKID"
# echo "VAR_1 is $VAR_1"
# echo "VAR_2 is $VAR_2"

