%% Лабораторная работа №3. Модель Simulink для получения переходной
%% и импульсной характеристик дискретного звена (вариант 12)
clear; clc; close all;
mdl = 'lab3_time';
T = 1;
c = [0.0569 0.5917 0.3846 1];
den = fliplr(c);                           % устойчивый вариант W2(z)

if bdIsLoaded(mdl), close_system(mdl, 0); end
if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
new_system(mdl); open_system(mdl);
try, set_param(mdl, 'HideAutomaticNames', 'off'); catch, end   % показывать имена блоков
add_block('simulink/Sources/Step', [mdl '/Step'], 'Time', '0', 'SampleTime', 'T', ...
    'Position', [20 60 60 100]);
add_block('simulink/Sources/Step', [mdl '/Step1'], 'Time', 'T', 'SampleTime', 'T', ...
    'Position', [20 210 60 250]);
add_block('simulink/Math Operations/Sum', [mdl '/Sum'], 'IconShape', 'rectangular', ...
    'Inputs', '+-', 'Position', [150 205 180 255]);
add_block('simulink/Discrete/Discrete Transfer Fcn', [mdl '/W step'], ...
    'Numerator', '1', 'Denominator', 'den', 'SampleTime', 'T', 'Position', [260 50 430 110]);
add_block('simulink/Discrete/Discrete Transfer Fcn', [mdl '/W impulse'], ...
    'Numerator', '1', 'Denominator', 'den', 'SampleTime', 'T', 'Position', [260 200 430 260]);
add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', '2', 'Position', [500 60 506 250]);
add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'Position', [560 130 605 180]);
add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace'], 'VariableName', 'y', ...
    'SaveFormat', 'Structure With Time', 'Position', [560 220 630 250]);
add_line(mdl, 'Step/1', 'W step/1', 'autorouting', 'on');
add_line(mdl, 'Step/1', 'Sum/1', 'autorouting', 'on');
add_line(mdl, 'Step1/1', 'Sum/2', 'autorouting', 'on');
add_line(mdl, 'Sum/1', 'W impulse/1', 'autorouting', 'on');
add_line(mdl, 'W step/1', 'Mux/1', 'autorouting', 'on');
add_line(mdl, 'W impulse/1', 'Mux/2', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'Scope/1', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'To Workspace/1', 'autorouting', 'on');
set_param(mdl, 'StopTime', '30');
save_system(mdl);
try
    print(['-s' mdl], '-dpng', '-r200', 'lab3_simulink_scheme.png');
catch err
    warning('Не удалось сохранить скриншот схемы: %s', err.message);
end

out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
ys = out.get('y');  t = ys.time;  Y = ys.signals.values;
figure('Name', 'Simulink: W2(z)');
subplot(1,2,1); stem(t, Y(:,2), 'filled'); grid on;
title('Импульсная характеристика'); xlabel('k'); ylabel('w[k]');
subplot(1,2,2); stairs(t, Y(:,1), 'LineWidth', 1.2); grid on;
title('Переходная характеристика'); xlabel('k'); ylabel('h[k]');
exportgraphics(gcf, 'lab3_simulink_results.png', 'Resolution', 200);

den = c;                                    % вариант W1(z): неустойчивое звено
set_param(mdl, 'StopTime', '11');
out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
ys = out.get('y');
disp('W1(z): переходная и импульсная последовательности');
disp([ys.time ys.signals.values]);
