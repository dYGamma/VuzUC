%% Лабораторная работа №3 «Временные характеристики дискретных систем»
%% Вариант 12: коэффициенты знаменателя 0.0569 0.5917 0.3846 1, K = 1
clear; clc; close all;
T = 1;                                     % период дискретизации, с

%% 1. Дискретное звено 1-го порядка W(z) = K/(z - a)
N = 21;
figure('Name', 'Звено 1-го порядка: влияние полюса a', 'Position', [100 100 760 860]);
subplot(3,1,1); hold on; grid on; box on;
for a = [0.9 0.7 0.5 0.2 0]
    [h, t] = step(tf(1-a, [1 -a], T), N-1);    % K = 1 - a, т.е. W(1) = 1
    stairs(t, h, 'LineWidth', 1.2);
end
ylim([0 1.35]); title('а) 0 \leq a < 1, K = 1 - a: монотонный процесс'); xlabel('k'); ylabel('h[k]');
legend('a = 0.9', 'a = 0.7', 'a = 0.5', 'a = 0.2', 'a = 0', 'Orientation', 'horizontal');
subplot(3,1,2); hold on; grid on; box on;
for a = [-0.2 -0.5 -0.8]
    [h, t] = step(tf(1-a, [1 -a], T), N-1);
    stairs(t, h, 'LineWidth', 1.2);
end
ylim([0 2.3]); title('б) -1 < a < 0, K = 1 - a: знакопеременный процесс'); xlabel('k'); ylabel('h[k]');
legend('a = -0.2', 'a = -0.5', 'a = -0.8', 'Orientation', 'horizontal');
subplot(3,1,3); hold on; grid on; box on;
for a = [1 -1 1.1 -1.1]
    h = filter(1, [1 -a], [0 ones(1, N-1)]);    % y(k) = a*y(k-1) + u(k-1)
    stairs(0:N-1, h, 'LineWidth', 1.2);
end
ylim([-6 12]);
title('в) |a| \geq 1, K = 1: граница устойчивости и неустойчивость');
xlabel('k'); ylabel('h[k]');
legend('a = 1', 'a = -1', 'a = 1.1', 'a = -1.1', 'Orientation', 'horizontal');

% Установившееся значение и число тактов переходного процесса (5 %)
fprintf('   a      K     h(inf)   k_п\n');
for a = [0.9 0.7 0.5 0.2 0 -0.2 -0.5 -0.8]
    W1 = tf(1-a, [1 -a], T);
    h  = step(W1, 0:T:200);  hinf = dcgain(W1);
    kp = find(abs(h - hinf) > 0.05*abs(hinf), 1, 'last');   % последний выход из зоны
    if isempty(kp), kp = 0; end
    fprintf('%5.1f  %5.2f  %6.3f  %4d\n', a, 1-a, hinf, kp);
end

% Влияние коэффициента K и периода дискретизации T
figure('Name', 'Звено 1-го порядка: влияние K и T');
subplot(1,2,1); hold on; grid on; box on;
for K = [0.25 0.5 1]
    [h, t] = step(tf(K, [1 -0.5], 1), 15);  stairs(t, h, 'LineWidth', 1.2);
end
title('Влияние K (a = 0.5, T = 1 c)'); xlabel('t, c'); ylabel('h(t)');
legend('K = 0.25', 'K = 0.5', 'K = 1', 'Location', 'southeast');
subplot(1,2,2); hold on; grid on; box on;
for Ti = [0.5 1 2]
    [h, t] = step(tf(0.5, [1 -0.5], Ti), 15);  stairs(t, h, 'LineWidth', 1.2);
end
title('Влияние T (a = 0.5, K = 0.5)'); xlabel('t, c'); ylabel('h(t)');
legend('T = 0.5 c', 'T = 1 c', 'T = 2 c', 'Location', 'southeast');

%% 2. Заданное звено (табл. 3.1, вариант 12)
c = [0.0569 0.5917 0.3846 1];

% а) коэффициенты по убыванию степеней z (соглашение MATLAB)
W1 = tf(1, c, T)
p1 = pole(W1), abs_p1 = abs(p1)
stab1 = isstable(W1)
[num1, den1] = tfdata(W1, 'v');
w1 = filter(num1, den1, [1 zeros(1, 11)])     % импульсная характеристика
h1 = filter(num1, den1, ones(1, 12))          % переходная характеристика
figure('Name', 'W1(z): коэффициенты по убыванию степеней z');
semilogy(3:11, abs(w1(4:12)), 'o-', 3:11, abs(h1(4:12)), 's--'); grid on;
xlim([0 11]); ylim([1 1e10]); xlabel('k'); ylabel('модуль отсчёта');
title('W1(z): модули отсчётов характеристик (знак чередуется)');
legend('|w[k]| (импульсная)', '|h[k]| (переходная)', 'Location', 'northwest');

% б) коэффициенты по возрастанию степеней z
W2 = tf(1, fliplr(c), T)
p2 = pole(W2), abs_p2 = abs(p2)
stab2 = isstable(W2)
hinf2 = dcgain(W2)
[num2, den2] = tfdata(W2, 'v');
figure('Name', 'W2(z): импульсная и переходная характеристики');
subplot(1,2,1);
try
    impz(num2, den2, 31);                      % Signal Processing Toolbox
catch
    stem(0:30, filter(num2, den2, [1 zeros(1, 30)]), 'filled');
end
grid on; title('Impulse Response'); xlabel('n (samples)'); ylabel('Amplitude');
subplot(1,2,2);
try
    dstep(num2, den2, 31);                     % как в методических указаниях
catch
    stairs(0:30, filter(num2, den2, ones(1, 31)), 'LineWidth', 1.2);
end
grid on; yline(hinf2, 'k--'); title('Step Response');
S2 = stepinfo(W2, 'SettlingTimeThreshold', 0.05)
w2 = filter(num2, den2, [1 zeros(1, 15)])
h2 = filter(num2, den2, ones(1, 16))

figure('Name', 'Полюса');
subplot(1,2,1); pzmap(W1); title('W1(z)'); axis equal;
subplot(1,2,2); pzmap(W2); title('W2(z)'); axis equal;
