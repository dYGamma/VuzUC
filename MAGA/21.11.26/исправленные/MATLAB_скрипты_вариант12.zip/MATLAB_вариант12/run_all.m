function run_all(which)
% RUN_ALL  Запуск всех лабораторных работ подряд (журналы и рисунки сохраняются в папках работ)
labs = {'LSU_Lab1','lsu_lab1_filters'; 'LSU_Lab1','lsu_lab1_model';
        'LSU_Lab2','lsu_lab2_discretization'; 'LSU_Lab2','lsu_lab2_model';
        'LSU_Lab3','lsu_lab3_time'; 'LSU_Lab3','lsu_lab3_model';
        'LSU_Lab4','lsu_lab4_freq'; 'LSU_Lab4','lsu_lab4_model';
        'LSU_Lab5','lsu_lab5_statespace'; 'LSU_Lab5','lsu_lab5_model';
        'LSU_Lab6','lsu_lab6_pid'; 'LSU_Lab6','lsu_lab6_model';
        'NASU_Lab1','nasu_lab1_lyapunov'; 'NASU_Lab1','nasu_lab1_model';
        'NASU_Lab2','nasu_lab2_sliding'; 'NASU_Lab2','nasu_lab2_model';
        'NASU_Lab3','nasu_lab3_fl'; 'NASU_Lab3','nasu_lab3_model'};
if nargin < 1, which = 1:size(labs, 1); end
for q = which
    fprintf('\n##### %d/%d: %s\n', q, size(labs, 1), labs{q,2});
    run_lab(labs{q,1}, labs{q,2});
    bdclose('all');                          % закрыть модели Simulink
end
fprintf('\nALL DONE\n');
end
