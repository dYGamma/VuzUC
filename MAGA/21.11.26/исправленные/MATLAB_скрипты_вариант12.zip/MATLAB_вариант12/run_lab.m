function run_lab(folder, script)
% RUN_LAB  Запуск скрипта лабораторной работы с журналом и экспортом рисунков.
%   run_lab('LSU_Lab1', 'lsu_lab1_filters')
root = '/MATLAB Drive/maga';
cd(fullfile(root, folder));
close all force;
logf = [script '_log.txt'];
if exist(logf, 'file'), delete(logf); end
old = dir([script '_fig*.png']);
for k = 1:numel(old), delete(old(k).name); end
diary(logf);
t0 = tic;
try
    evalin('base', script);
    fprintf('\n=== %s: OK (%.1f s)\n', script, toc(t0));
catch err
    fprintf('\n=== %s: ERROR\n%s\n', script, err.getReport('extended', 'hyperlinks', 'off'));
end
diary off;
figs = findobj(groot, 'Type', 'figure');
if ~isempty(figs)
    [~, idx] = sort([figs.Number]); figs = figs(idx);
end
for k = 1:numel(figs)
    fn = sprintf('%s_fig%d.png', script, figs(k).Number);
    try
        exportgraphics(figs(k), fn, 'Resolution', 150);
    catch e2
        fprintf('export %s failed: %s\n', fn, e2.message);
    end
end
fprintf('=== %d figures exported\n', numel(figs));
end
