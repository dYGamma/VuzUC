%% Лабораторная работа №3 «Исследование линеаризации обратной связью»
%% Вариант 12: желаемые полюса замкнутой системы P = [-1 -5]
clear; clc; close all;
P  = [-1 -5];
A0 = [0 1; 0 0];  B0 = [0; 1];             % линеаризованная система z' = A0 z + B0 v
K  = place(A0, B0, P)                      % модальный синтез: K = [5 6]
k1 = K(1);  k2 = K(2);
eig(A0 - B0*K)                             % проверка: -1, -5
opts = odeset('RelTol', 1e-9, 'AbsTol', 1e-11, 'MaxStep', 0.002);
lin  = @(z0, t) initial(ss(A0 - B0*K, zeros(2,1), eye(2), zeros(2,1)), z0, t);
tt   = (0:0.002:8)';

%% Задание 8.1:  x1' = a sin x2,  x2' = -x1^2 + u   (принято a = 1)
a   = 1;
u81 = @(x) x(1)^2 - (k1*x(1) + k2*a*sin(x(2)))/(a*cos(x(2)));
f81 = @(t, x) [a*sin(x(2)); -x(1)^2 + u81(x)];
[t, X] = ode45(f81, tt, [1; 0], opts);
Z = lin([1; a*sin(0)], t);  U = ufun(u81, X);
fprintf('8.1: max|x1 - z1| = %.1e, min x2 = %.4f рад, x1(3) = %.4f, max|u| = %.3f\n', ...
    max(abs(X(:,1) - Z(:,1))), min(X(:,2)), interp1(t, X(:,1), 3), max(abs(U)));
z2max = max(abs(Z(:,2)));                % наибольшее |z2| = |a sin x2| на траектории
fprintf('8.1: max|z2| = %.3f; закон корректен при x2(0) = 0, если x1(0) < a/max|z2| = %.3f\n', ...
    z2max, a/z2max);
plot_task('Задание 8.1 (a = 1): x(0) = [1; 0]', t, X, U, Z);

%% Задание 8.2:  x1' = x2 + x1^3,  x2' = -u
u82 = @(x) 3*x(1)^2*(x(2) + x(1)^3) + k1*x(1) + k2*(x(2) + x(1)^3);
f82 = @(t, x) [x(2) + x(1)^3; -u82(x)];
[t, X] = ode45(f82, tt, [1; -1], opts);
Z = lin([1; -1 + 1], t);  U = ufun(u82, X);
fprintf('8.2: max|x1 - z1| = %.1e, x1(3) = %.4f, max|u| = %.3f\n', ...
    max(abs(X(:,1) - Z(:,1))), interp1(t, X(:,1), 3), max(abs(U)));
plot_task('Задание 8.2: x(0) = [1; -1]', t, X, U, Z);

%% Задание 8.3:  x1' = -3x1 + 2x1x2^2,  x2' = -x2^3 - u
try                                         % проверка условий линеаризуемости
    syms x1 x2 real
    f = [-3*x1 + 2*x1*x2^2; -x2^3];  g = [0; -1];
    adfg = simplify(jacobian(g, [x1 x2])*f - jacobian(f, [x1 x2])*g)
    detG = simplify(det([g adfg]))          % = 4*x1*x2: вырождается в нуле
    Alin = double(subs(jacobian(f, [x1 x2]), [x1 x2], [0 0]))
    rank_ctrb = rank(ctrb(Alin, double(g))) % = 1: линеаризация в нуле неуправляема
catch
    disp('Symbolic Math Toolbox недоступен');
end
% а) формальная линеаризация z1 = x1, z2 = x1' (вырождена при x1*x2 = 0)
u83f = @(x) -x(2)^3 - (-k1*x(1) - k2*x(1)*(-3 + 2*x(2)^2) - x(1)*(-3 + 2*x(2)^2)^2)/(4*x(1)*x(2));
f83f = @(t, x) [-3*x(1) + 2*x(1)*x(2)^2; -x(2)^3 - u83f(x)];
[t, X] = ode45(f83f, (0:0.002:10)', [1; 0.5], opts);
fprintf('8.3 (формально): x1(10) = %.2e, x2(10) = %.4f (теория: sqrt((3+p1)/2) = %.4f)\n', ...
    X(end,1), X(end,2), sqrt((3 + P(1))/2));
figure('Name', 'Задание 8.3'); subplot(3,1,1); plot(t, X, 'LineWidth', 1.3); grid on;
title('а) формальная линеаризация, x(0) = [1; 0.5]: x_2 \rightarrow 1, а не к 0'); legend('x_1', 'x_2');
% б) линеаризация по выходу y = x2 + интегратор xi' = x2:  u = -x2^3 - v,  v = -k1*xi - k2*x2
u83 = @(x) -x(2)^3 + k1*x(3) + k2*x(2);
f83 = @(t, x) [-3*x(1) + 2*x(1)*x(2)^2; -x(2)^3 - u83(x); x(2)];
[t, X] = ode45(f83, (0:0.002:10)', [1; 1; 0], opts);
fprintf('8.3 (по выходу): x1(3) = %.2e, x2(3) = %.4f, max|u| = %.3f\n', ...
    interp1(t, X(:,1), 3), interp1(t, X(:,2), 3), max(abs(ufun(u83, X))));
subplot(3,1,2); plot(t, X, 'LineWidth', 1.3); grid on; legend('x_1', 'x_2', '\xi');
title('б) линеаризация по выходу y = x_2 с интегратором: x(0) = [1; 1]');
[t, X] = ode45(f83, (0:0.002:10)', [1; 1.5; 0], opts);
fprintf('8.3 (по выходу), x(0) = [1; 1.5]: max x1 = %.4f\n', max(X(:,1)));
subplot(3,1,3); plot(t, X(:,1:2), 'LineWidth', 1.3); grid on; legend('x_1', 'x_2');
title('в) то же при x(0) = [1; 1.5]'); xlabel('t, c');

%% Задание 8.4:  x1' = x2^3 sin x2,  x2' = u
phi  = @(x2) x2.^3.*sin(x2);
dphi = @(x2) 3*x2.^2.*sin(x2) + x2.^3.*cos(x2);
r1 = fzero(@(x) 3*sin(x) + x.*cos(x), [2 3])       % нули phi'(x2): 2.4556 ...
r2 = fzero(@(x) 3*sin(x) + x.*cos(x), [4.5 5.8])   % ... и 5.2329
dphi_pi = dphi(pi)                                  % = -pi^3: точка x2 = pi регулярна
fprintf('8.4: phi(r1) = %.2f, phi(r2) = %.1f, phi(3) = %.2f\n', phi(r1), phi(r2), phi(3));
x2g = linspace(-6.5, 6.5, 2001);
figure('Name', 'Задание 8.4: функции phi и dphi', 'Position', [100 100 820 360]);
subplot(1,2,1); plot(x2g, phi(x2g), 'LineWidth', 1.3); hold on; grid on;
xregion(r1, r2, 'FaceColor', [0.47 0.67 0.19]); xline(pi, 'k:');
xlim([-6.5 6.5]); ylim([-135 40]); xlabel('x_2'); title('\phi(x_2) = x_2^3 sin x_2');
subplot(1,2,2); plot(x2g, dphi(x2g), 'LineWidth', 1.3); hold on; grid on; yline(0, 'k');
xregion(r1, r2, 'FaceColor', [0.47 0.67 0.19]); xline(pi, 'k:');
xlim([-6.5 6.5]); ylim([-140 140]); xlabel('x_2'); title('\phi''(x_2)');
u84 = @(x) (-k1*x(1) - k2*phi(x(2)))/dphi(x(2));
f84 = @(t, x) [phi(x(2)); u84(x)];
% попытка стабилизации начала координат из x(0) = [1; 0.5]: phi'(x2) -> 0
ev = @(t, x) event84(t, x, dphi);          % остановка, когда |phi'(x2)| < 1e-3
[t, X] = ode45(f84, [0 8], [1; 0.5], odeset(opts, 'Events', ev));
fprintf('8.4 (около нуля): остановка при t = %.4f c, x2 = %.4f, u = %.1f\n', t(end), X(end,2), u84(X(end,:)'));
figure('Name', 'Задание 8.4: рост управления');
semilogy(t*1e3, abs(ufun(u84, X)), 'LineWidth', 1.3); grid on;
xlabel('t, мс'); ylabel('|u|');
title('Попытка стабилизации начала координат из x(0) = [1; 0.5]: |u| \rightarrow \infty');
% регулирование x1 -> 0 при x2 -> pi
[t, X] = ode45(f84, tt, [1; 3], opts);
Z = lin([1; phi(3)], t);  U = ufun(u84, X);
fprintf('8.4: x2(8) = %.4f, x1(8) = %.2e, x2 в [%.3f, %.3f], max|x1 - z1| = %.1e\n', ...
    X(end,2), X(end,1), min(X(:,2)), max(X(:,2)), max(abs(X(:,1) - Z(:,1))));
fprintf('8.4: z2 линейной модели в [%.2f, %.2f], max|u| = %.2f\n', min(Z(:,2)), max(Z(:,2)), max(abs(U)));
plot_task('Задание 8.4: x_1 \rightarrow 0, x_2 \rightarrow \pi, x(0) = [1; 3]', t, X, U, Z);

%% Задание 8.5: маятник  x2' = -g/l sin x1 - b/m x2 + u/(m l^2)
g = 9.81;  l = 1;  m = 1;  b = 0.5;        % принятые параметры маятника
A5 = [0 1; 0 -b/m];  B5 = [0; 1/(m*l^2)];
K5 = place(A5, B5, P)                      % [5 5.5]
u85 = @(x) g*l*m*sin(x(1)) - K5*x;         % u = glm sin(x1) + v,  v = -K5 x
f85 = @(t, x) [x(2); -g/l*sin(x(1)) - b/m*x(2) + u85(x)/(m*l^2)];
Alin = [0 1; -g/l -b/m];
Klin = place(Alin, B5, P)                  % регулятор по линеаризации в нуле (якобиан)
ulin = @(x) -Klin*x;
flin = @(t, x) [x(2); -g/l*sin(x(1)) - b/m*x(2) + ulin(x)/(m*l^2)];
t5 = (0:0.002:10)';
[t, X]  = ode45(f85, t5, [2.5; 0], opts);
[~, XL] = ode45(flin, t5, [2.5; 0], opts);
Z = initial(ss(A5 - B5*K5, zeros(2,1), eye(2), zeros(2,1)), [2.5; 0], t);
fprintf('8.5: x1(3) = %.4f (ЛОС), %.3f (линейный регулятор); max|x1 - z1| = %.1e\n', ...
    interp1(t, X(:,1), 3), interp1(t, XL(:,1), 3), max(abs(X(:,1) - Z(:,1))));
fprintf('8.5: max|u| = %.2f (ЛОС)\n', max(abs(ufun(u85, X))));
figure('Name', 'Задание 8.5');
subplot(2,1,1); plot(t, X(:,1), t, Z(:,1), 'k--', t, XL(:,1), 'LineWidth', 1.3); grid on;
ylim([-1 8]); ylabel('x_1, рад'); title('Задание 8.5: маятник, x_1(0) = 2.5 рад');
legend('линеаризация обратной связью', 'линейная модель', 'линейный регулятор по якобиану');
subplot(2,1,2); plot(t, ufun(u85, X), t, ufun(ulin, XL), 'LineWidth', 1.3); grid on;
ylim([-15 25]); xlabel('t, c'); ylabel('u, Н\cdotм'); legend('линеаризация обратной связью', 'линейный регулятор');

%% ------------------------------------------------------------------------
function U = ufun(u, X)
U = zeros(size(X,1), 1);
for i = 1:size(X,1), U(i) = u(X(i,:)'); end
end

function [val, isterminal, direction] = event84(~, x, dphi)
% Событие для ode45: производная phi'(x2) почти обратилась в нуль
val = abs(dphi(x(2))) - 1e-3;  isterminal = 1;  direction = 0;
end

function plot_task(ttl, t, X, U, Z)
figure('Name', ttl);
subplot(2,1,1); plot(t, X(:,1), t, X(:,2), 'LineWidth', 1.3); hold on;
plot(t, Z(:,1), 'k--'); grid on; legend('x_1', 'x_2', 'z_1 линейной модели'); title(ttl);
subplot(2,1,2); plot(t, U, 'LineWidth', 1.3); grid on; xlabel('t, c'); ylabel('u(t)'); title('Управление');
end
