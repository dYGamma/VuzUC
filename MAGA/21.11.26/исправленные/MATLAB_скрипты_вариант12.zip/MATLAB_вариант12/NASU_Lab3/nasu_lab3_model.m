%% Лабораторная работа №3. Модели Simulink для заданий 8.1–8.5 (вариант 12)
clear; clc; close all;
P = [-1 -5];
K = place([0 1; 0 0], [0; 1], P);  k1 = K(1);  k2 = K(2);
a = 1;  g = 9.81;  l = 1;  m = 1;  b = 0.5;
K5 = place([0 1; 0 -b/m], [0; 1/(m*l^2)], P);  q1 = K5(1);  q2 = K5(2);
% {имя модели, f1, f2, закон управления, x(0), время, интегратор xi}
cfg = {
 'lab3_task81', 'a*sin(u(2))', '-u(1)^2+u(3)', ...
     'u(1)^2-(k1*u(1)+k2*a*sin(u(2)))/(a*cos(u(2)))', [1 0], 8, false;
 'lab3_task82', 'u(2)+u(1)^3', '-u(3)', ...
     '3*u(1)^2*(u(2)+u(1)^3)+k1*u(1)+k2*(u(2)+u(1)^3)', [1 -1], 8, false;
 'lab3_task83', '-3*u(1)+2*u(1)*u(2)^2', '-u(2)^3-u(4)', ...
     '-u(2)^3+k1*u(3)+k2*u(2)', [1 1], 10, true;
 'lab3_task84', 'u(2)^3*sin(u(2))', 'u(3)', ...
     '(-k1*u(1)-k2*u(2)^3*sin(u(2)))/(3*u(2)^2*sin(u(2))+u(2)^3*cos(u(2)))', [1 3], 8, false;
 'lab3_task85', 'u(2)', '-g/l*sin(u(1))-b/m*u(2)+u(3)/(m*l^2)', ...
     'g*l*m*sin(u(1))-q1*u(1)-q2*u(2)', [2.5 0], 10, false};
for j = 1:size(cfg, 1)
    [mdl, f1, f2, ulaw, x0, tend, withXi] = cfg{j,:};
    if bdIsLoaded(mdl), close_system(mdl, 0); end
    if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
    new_system(mdl); open_system(mdl);
    try, set_param(mdl, 'HideAutomaticNames', 'off'); catch, end   % показывать имена блоков
    ns = 2 + withXi;                        % число переменных состояния
    add_block('simulink/User-Defined Functions/Fcn', [mdl '/Control law'], 'Expr', ulaw, ...
        'Position', [70 135 240 175]);
    add_block('simulink/Signal Routing/Mux', [mdl '/Mux1'], 'Inputs', '2', 'Position', [275 105 281 205]);
    add_block('simulink/User-Defined Functions/Fcn', [mdl '/f1'], 'Expr', f1, 'Position', [330 40 530 80]);
    add_block('simulink/User-Defined Functions/Fcn', [mdl '/f2'], 'Expr', f2, 'Position', [330 230 530 270]);
    add_block('simulink/Continuous/Integrator', [mdl '/Integrator x1'], ...
        'InitialCondition', num2str(x0(1)), 'Position', [580 40 625 80]);
    add_block('simulink/Continuous/Integrator', [mdl '/Integrator x2'], ...
        'InitialCondition', num2str(x0(2)), 'Position', [580 230 625 270]);
    add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', num2str(ns), ...
        'Position', [690 80 696 300]);
    add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'Position', [830 165 875 215]);
    add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace'], 'VariableName', 'xs', ...
        'SaveFormat', 'Structure With Time', 'Position', [830 40 900 70]);
    add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace1'], 'VariableName', 'us', ...
        'SaveFormat', 'Structure With Time', 'Position', [240 60 310 90]);
    L = {'f1/1','Integrator x1/1'; 'f2/1','Integrator x2/1'; 'Integrator x1/1','Mux/1';
         'Integrator x2/1','Mux/2'; 'Mux/1','Scope/1'; 'Mux/1','To Workspace/1';
         'Mux/1','Control law/1'; 'Mux/1','Mux1/1'; 'Control law/1','Mux1/2';
         'Mux1/1','f1/1'; 'Mux1/1','f2/1'; 'Control law/1','To Workspace1/1'};
    if withXi                               % интегратор xi' = x2 (задание 8.3)
        add_block('simulink/Continuous/Integrator', [mdl '/Integrator xi'], ...
            'InitialCondition', '0', 'Position', [580 320 625 360]);
        L = [L; {'Integrator x2/1','Integrator xi/1'; 'Integrator xi/1','Mux/3'}];
    end
    for i = 1:size(L,1), add_line(mdl, L{i,1}, L{i,2}, 'autorouting', 'on'); end
    set_param(mdl, 'StopTime', num2str(tend), 'MaxStep', '0.002', 'RelTol', '1e-8');
    save_system(mdl);
    try, print(['-s' mdl], '-dpng', '-r200', [mdl '_scheme.png']); catch, end
    out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
    xs = out.get('xs');  us = out.get('us');  RES{j} = xs;
    [tu, iu] = unique(xs.time);
    fprintf('%s: x1(3) = %.4g, x2(end) = %.4f, max|u| = %.3f\n', mdl, ...
        interp1(tu, xs.signals.values(iu,1), 3), xs.signals.values(end,2), max(abs(us.signals.values)));
    figure('Name', mdl);
    subplot(2,1,1); plot(xs.time, xs.signals.values, 'LineWidth', 1.3); grid on;
    title(['Simulink: ' strrep(mdl, '_', '\_')]); legend(compose('x_%d', 1:ns));
    subplot(2,1,2); plot(us.time, us.signals.values, 'LineWidth', 1.3); grid on;
    xlabel('t, c'); ylabel('u');
    exportgraphics(gcf, [mdl '_results.png'], 'Resolution', 200);
end

%% Сводный рисунок результатов моделирования в Simulink
figure('Name', 'Simulink: задания 8.1–8.5', 'Position', [100 100 820 980]);
ttl = {'8.1: x(0) = [1; 0]', '8.2: x(0) = [1; -1]', ...
       '8.3 (по выходу y = x_2 с интегратором): x(0) = [1; 1]', ...
       '8.4: x(0) = [1; 3], x_2 \rightarrow \pi', '8.5 (маятник): x(0) = [2.5; 0]'};
for j = 1:5
    subplot(5,1,j); plot(RES{j}.time, RES{j}.signals.values(:,1:2), 'LineWidth', 1.2); grid on;
    title(['Simulink, задание ' ttl{j}]); legend('x_1', 'x_2', 'Location', 'eastoutside');
end
xlabel('t, c');
exportgraphics(gcf, 'lab3_simulink_summary.png', 'Resolution', 200);

%% Структура системы с линеаризацией обратной связью (рис. 35 методических указаний)
mdl = 'lab3_structure';
if bdIsLoaded(mdl), close_system(mdl, 0); end
if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
new_system(mdl); open_system(mdl);
add_block('simulink/Sources/Constant', [mdl '/Задание z* = 0'], 'Value', '0', 'Position', [20 95 60 125]);
add_block('simulink/Math Operations/Sum', [mdl '/Sum'], 'IconShape', 'round', 'Inputs', '|+-', ...
    'Position', [110 97 136 123]);
add_block('simulink/Math Operations/Gain', [mdl '/Линейное управление v = -Kz'], 'Gain', 'K', ...
    'Position', [175 90 235 130]);
add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', '2', 'Position', [285 80 290 145]);
add_block('simulink/Ports & Subsystems/Subsystem', ...
    [mdl '/Нелинейное управление u = α(x) + β(x)v'], 'Position', [330 85 450 135]);
add_block('simulink/Ports & Subsystems/Subsystem', ...
    [mdl '/Объект x'' = f(x) + g(x)u'], 'Position', [500 85 620 135]);
add_block('simulink/Sinks/Out1', [mdl '/x'], 'Position', [700 103 730 117]);
add_block('simulink/Ports & Subsystems/Subsystem', ...
    [mdl '/Преобразование координат z = T(x)'], 'Orientation', 'left', 'Position', [330 200 450 250]);
add_line(mdl, 'Задание z* = 0/1', 'Sum/1', 'autorouting', 'on');
add_line(mdl, 'Sum/1', 'Линейное управление v = -Kz/1', 'autorouting', 'on');
add_line(mdl, 'Линейное управление v = -Kz/1', 'Mux/1', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'Нелинейное управление u = α(x) + β(x)v/1', 'autorouting', 'on');
add_line(mdl, 'Нелинейное управление u = α(x) + β(x)v/1', 'Объект x'' = f(x) + g(x)u/1', 'autorouting', 'on');
add_line(mdl, 'Объект x'' = f(x) + g(x)u/1', 'x/1', 'autorouting', 'on');
add_line(mdl, 'Объект x'' = f(x) + g(x)u/1', 'Mux/2', 'autorouting', 'on');
add_line(mdl, 'Объект x'' = f(x) + g(x)u/1', 'Преобразование координат z = T(x)/1', 'autorouting', 'on');
add_line(mdl, 'Преобразование координат z = T(x)/1', 'Sum/2', 'autorouting', 'on');
save_system(mdl);
try, print(['-s' mdl], '-dpng', '-r200', 'lab3_structure_scheme.png'); catch err, disp(err.message); end
