%% Лабораторная работа №6. Схема переоборудования ПИД-регулятора (рис. 5.1)
%% Сборка модели Simulink и исследование влияния шага квантования (вариант 12)
clear; clc; close all;
mdl = 'lab6_pid';
Kp = 2;  Ki = 0.25;  Kd = 5;               % настройки ПИД-регулятора
T  = 0.1;  q = 0.001;                      % шаг квантования по времени и по уровню
numD = [2 -2];  denD = [T T];              % дифференциальный канал (Тастин)

if bdIsLoaded(mdl), close_system(mdl, 0); end
if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
new_system(mdl); open_system(mdl);
try, set_param(mdl, 'HideAutomaticNames', 'off'); catch, end   % показывать имена блоков
add_block('simulink/Sources/Step', [mdl '/Step'], 'Time', '0', 'Position', [15 245 55 285]);
% ---- аналоговый контур
add_block('simulink/Math Operations/Sum', [mdl '/Sum'], 'IconShape', 'round', ...
    'Inputs', '|+-', 'Position', [105 97 131 123]);
add_block('simulink/Math Operations/Gain', [mdl '/Kp'], 'Gain', 'Kp', 'Position', [165 35 205 65]);
add_block('simulink/Math Operations/Gain', [mdl '/Ki'], 'Gain', 'Ki', 'Position', [165 95 205 125]);
add_block('simulink/Math Operations/Gain', [mdl '/Kd'], 'Gain', 'Kd', 'Position', [165 155 205 185]);
add_block('simulink/Continuous/Integrator', [mdl '/Integrator'], 'Position', [240 90 290 130]);
add_block('simulink/Continuous/Transfer Fcn', [mdl '/Real diff'], 'Numerator', '[1 0]', ...
    'Denominator', '[0.01 1]', 'Position', [230 150 300 190]);
add_block('simulink/Math Operations/Sum', [mdl '/Sum1'], 'IconShape', 'rectangular', ...
    'Inputs', '+++', 'Position', [345 20 367 200]);
add_block('simulink/Continuous/Transfer Fcn', [mdl '/Object'], 'Numerator', '0.5', ...
    'Denominator', '[1 2 1 0]', 'Position', [420 85 540 135]);
% ---- цифровой контур
add_block('simulink/Math Operations/Sum', [mdl '/Sum2'], 'IconShape', 'round', ...
    'Inputs', '|+-', 'Position', [105 377 131 403]);
add_block('simulink/Discontinuities/Quantizer', [mdl '/Quantizer'], ...
    'QuantizationInterval', 'q', 'Position', [145 374 177 406]);
add_block('simulink/Math Operations/Gain', [mdl '/Kp1'], 'Gain', 'Kp', 'Position', [245 315 285 345]);
add_block('simulink/Math Operations/Gain', [mdl '/Ki1'], 'Gain', 'Ki', 'Position', [245 375 285 405]);
add_block('simulink/Math Operations/Gain', [mdl '/Kd1'], 'Gain', 'Kd', 'Position', [245 435 285 465]);
add_block('simulink/Discrete/Discrete Transfer Fcn', [mdl '/Discrete int'], ...
    'Numerator', 'T', 'Denominator', '[1 -1]', 'SampleTime', 'T', 'Position', [315 370 375 410]);
add_block('simulink/Discrete/Discrete Transfer Fcn', [mdl '/Discrete diff'], ...
    'Numerator', 'numD', 'Denominator', 'denD', 'SampleTime', 'T', 'Position', [310 430 380 470]);
add_block('simulink/Math Operations/Sum', [mdl '/Sum3'], 'IconShape', 'rectangular', ...
    'Inputs', '+++', 'Position', [420 300 442 480]);
add_block('simulink/Discrete/Zero-Order Hold', [mdl '/Zero-Order Hold'], 'SampleTime', 'T', ...
    'Position', [470 373 504 407]);
add_block('simulink/Continuous/Transfer Fcn', [mdl '/Object1'], 'Numerator', '0.5', ...
    'Denominator', '[1 2 1 0]', 'Position', [540 365 660 415]);
% ---- регистрация
add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', '2', 'Position', [790 150 796 350]);
add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'Position', [830 225 870 275]);
add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace'], 'VariableName', 'y', ...
    'SaveFormat', 'Structure With Time', 'Position', [830 300 900 330]);
add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace1'], 'VariableName', 'u', ...
    'SaveFormat', 'Structure With Time', 'Position', [540 300 610 330]);
% ---- соединения
L = {'Step/1','Sum/1'; 'Step/1','Sum2/1'; 'Sum/1','Kp/1'; 'Sum/1','Ki/1'; 'Sum/1','Kd/1';
     'Ki/1','Integrator/1'; 'Kd/1','Real diff/1'; 'Kp/1','Sum1/1'; 'Integrator/1','Sum1/2';
     'Real diff/1','Sum1/3'; 'Sum1/1','Object/1'; 'Object/1','Sum/2'; 'Object/1','Mux/1';
     'Sum2/1','Quantizer/1'; 'Quantizer/1','Kp1/1'; 'Quantizer/1','Ki1/1';
     'Quantizer/1','Kd1/1'; 'Ki1/1','Discrete int/1'; 'Kd1/1','Discrete diff/1'; 'Kp1/1','Sum3/1';
     'Discrete int/1','Sum3/2'; 'Discrete diff/1','Sum3/3'; 'Sum3/1','Zero-Order Hold/1';
     'Zero-Order Hold/1','Object1/1'; 'Zero-Order Hold/1','To Workspace1/1';
     'Object1/1','Sum2/2'; 'Object1/1','Mux/2'; 'Mux/1','Scope/1'; 'Mux/1','To Workspace/1'};
for i = 1:size(L, 1)
    add_line(mdl, L{i,1}, L{i,2}, 'autorouting', 'on');
end
set_param(mdl, 'StopTime', '40', 'MaxStep', '0.005');
save_system(mdl);
try
    print(['-s' mdl], '-dpng', '-r200', 'lab6_simulink_scheme.png');
catch err
    warning('Не удалось сохранить скриншот схемы: %s', err.message);
end

%% Влияние шага квантования по времени
fprintf('\n   T     sigma, %%   t_п, c   IAE(0-30)\n');
Tlist = [0.01 0.05 0.1 0.2 0.5 0.8 1 1.2];
figure('Name', 'Аналоговый и цифровой ПИД');  np = 0;
for T = Tlist
    denD = [T T];
    out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
    ys = out.get('y');  t = ys.time;  Y = ys.signals.values;
    [sig_d, ts_d, iae_d] = quality(t, Y(:,2));
    if T == Tlist(1)
        [sig_c, ts_c, iae_c] = quality(t, Y(:,1));
        fprintf('аналог.  %7.2f  %7.2f  %7.3f\n', sig_c, ts_c, iae_c);
    end
    fprintf('%5.2f  %8.2f  %7.2f  %7.3f\n', T, sig_d, ts_d, iae_d);
    if any(T == [0.1 0.5 1])
        np = np + 1;  subplot(3,1,np);
        plot(t, Y(:,1), 'LineWidth', 1.3); hold on; plot(t, Y(:,2), 'LineWidth', 1.2);
        grid on; xlim([0 40]); ylim([0 2]); ylabel('y(t)');
        title(sprintf('T = %g c: \\sigma = %.1f %%, t_п = %.1f c', T, sig_d, ts_d));
        legend('аналоговый ПИД', sprintf('цифровой ПИД, T = %g c', T));
    end
end
xlabel('t, c');
exportgraphics(gcf, 'lab6_simulink_results.png', 'Resolution', 200);

%% Управляющий сигнал при разных способах дискретизации D-канала (T = 0.1 c)
T = 0.1;  Tf = 0.01;
variants = {[2 -2], [T T]; [2 -2], [2*Tf+T, T-2*Tf]; [1 -1], [T 0]};
names = {'2(z-1)/(T(z+1)) — как на рис. 5.1', 'Тастин для s/(Tf s+1)', ...
         '(z-1)/(Tz) — обратные разности'};
figure('Name', 'Дифференциальный канал');
for i = 1:3
    numD = variants{i,1};  denD = variants{i,2};
    out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
    us = out.get('u');  ys = out.get('y');
    subplot(2,1,1); stairs(us.time, us.signals.values, 'LineWidth', 1); hold on;
    subplot(2,1,2); plot(ys.time, ys.signals.values(:,2), 'LineWidth', 1.2); hold on;
end
subplot(2,1,1); grid on; xlim([0 3]); ylim([-110 110]); ylabel('u(t)'); legend(names);
title('Управляющий сигнал цифрового ПИД, T = 0.1 c');
subplot(2,1,2); grid on; xlim([0 40]); ylim([0 1.3]); xlabel('t, c'); ylabel('y(t)');
title('Выход системы');

%% Перерегулирование при разных способах дискретизации D-канала (табл. 2)
Wobj = tf(0.5, [1 2 1 0]);                 % объект (для проверки устойчивости)
Tv = [0.1 0.5 1];
fprintf('\n D-канал                  sigma, %% (T = 0.1 / 0.5 / 1 c)   max|z| (T = 0.1 / 0.5 / 1 c)\n');
for v = 1:3
    sg = zeros(1, 3);  rz = zeros(1, 3);
    for j = 1:3
        T = Tv(j);
        switch v
            case 1, numD = [2 -2];  denD = [T T];                 % 2(z-1)/(T(z+1))
            case 2, numD = [2 -2];  denD = [2*Tf+T, T-2*Tf];      % Тастин для s/(Tf s+1)
            case 3, numD = [1 -1];  denD = [T 0];                 % (z-1)/(Tz)
        end
        Cd = Kp + Ki*tf(T, [1 -1], T) + Kd*tf(numD, denD, T);
        rz(j) = max(abs(pole(feedback(Cd*c2d(Wobj, T, 'zoh'), 1))));
        out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
        ys = out.get('y');  sg(j) = (max(ys.signals.values(:,2)) - 1)*100;
        if rz(j) >= 1, sg(j) = Inf; end                       % неустойчивая система
    end
    fprintf(' %-24s %7.1f %7.1f %7.1f        %8.4f %8.4f %8.4f\n', names{v}(1:min(end,24)), sg, rz);
end

%% Настройки Зиглера–Николса: аналоговый и цифровой регуляторы при T = 0.1 c
Kp = 0.6*4;  Ki = Kp/(0.5*2*pi);  Kd = Kp*0.125*2*pi;      % Ku = 4, Tu = 2*pi
T = 0.1;  numD = [2 -2];  denD = [T T];
out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
ys = out.get('y');  Y = ys.signals.values;
fprintf('\nЗиглер–Николс: sigma аналогового = %.1f %%, цифрового (T = 0.1 c) = %.1f %%\n', ...
    (max(Y(:,1)) - 1)*100, (max(Y(:,2)) - 1)*100);
Kp = 2;  Ki = 0.25;  Kd = 5;               % возврат к принятым настройкам

function [sigma, ts, iae] = quality(t, y)
% перерегулирование, время переходного процесса (5 %), интеграл |e| на 0..30 c
sigma = (max(y) - 1)*100;
i = find(abs(y - 1) > 0.05, 1, 'last');
if isempty(i), ts = 0; elseif i == numel(t), ts = Inf; else, ts = t(i+1); end
m = t <= 30;
iae = trapz(t(m), abs(1 - y(m)));
end
