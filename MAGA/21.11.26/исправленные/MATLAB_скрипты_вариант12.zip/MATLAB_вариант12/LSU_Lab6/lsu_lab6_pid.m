%% Лабораторная работа №6 «Цифровой ПИД регулятор при управлении
%% непрерывным объектом». Вариант 12:  W(s) = 0.5/(s(s+1)(s+1))
clear; clc; close all;
W  = tf(0.5, conv([1 0], conv([1 1], [1 1])))      % объект управления
Tf = 0.01;                                 % постоянная времени реального дифференцирования

%% 1. Синтез аналогового ПИД-регулятора методом Зиглера–Николса
% Предельный коэффициент усиления П-регулятора и период колебаний
[Gm, ~, wu] = margin(W);
Ku = Gm, wu, Tu = 2*pi/wu
Kp_zn = 0.6*Ku;  Ti_zn = 0.5*Tu;  Td_zn = 0.125*Tu;
Ki_zn = Kp_zn/Ti_zn, Kd_zn = Kp_zn*Td_zn
C_zn  = pid(Kp_zn, Ki_zn, Kd_zn, Tf);       % Kp + Ki/s + Kd*s/(Tf*s+1)
S_zn  = stepinfo(feedback(C_zn*W, 1), 'SettlingTimeThreshold', 0.05)

%% 2. Уточнение настроек: минимум ITAE при перерегулировании не более 10 %
t = (0:0.01:60)';  best = [Inf 0 0 0];
for Kp = 0.6:0.1:2.6
    for Ti = [3 4 5 6 8 10 12 15 20]
        for Td = 0.5:0.25:3
            Gcl = feedback(pid(Kp, Kp/Ti, Kp*Td, Tf)*W, 1);
            if ~isstable(Gcl), continue; end
            y = step(Gcl, t);
            if (max(y) - 1)*100 > 10, continue; end
            itae = trapz(t, t.*abs(1 - y));
            if itae < best(1), best = [itae Kp Ti Td]; end
        end
    end
end
best
Kp = 2;  Ti = 8;  Td = 2.5;                % принятые настройки (результат поиска)
Ki = Kp/Ti, Kd = Kp*Td
C  = pid(Kp, Ki, Kd, Tf)
Gcl = feedback(C*W, 1);
S  = stepinfo(Gcl, 'SettlingTimeThreshold', 0.05)
p_cl = pole(Gcl)
figure('Name', 'Аналоговый ПИД');
step(feedback(C_zn*W, 1), Gcl, 40); grid on;
legend(sprintf('Зиглер–Николс: Kp=%.3g, Ki=%.3g, Kd=%.3g', Kp_zn, Ki_zn, Kd_zn), ...
    sprintf('уточнённые: Kp=%.3g, Ki=%.3g, Kd=%.3g', Kp, Ki, Kd), 'Location', 'southeast');
title('Переходные процессы системы с аналоговым ПИД-регулятором');

%% 3. Переоборудование в цифровой ПИД-регулятор (как на рис. 5.1)
% P: Kp;  I: метод Эйлера Ki*T/(z-1);  D: преобразование Тастина Kd*2(z-1)/(T(z+1))
fprintf('\n   T      max|z| замкнутой системы\n');
for T = [0.01 0.05 0.1 0.2 0.5 0.8 1 1.2 1.5]
    Cd  = Kp + Ki*tf(T, [1 -1], T) + Kd*tf([2 -2], [T T], T);
    Wd  = c2d(W, T, 'zoh');                % объект с фиксатором нулевого порядка
    CLd = feedback(Cd*Wd, 1);
    fprintf('%5.2f   %8.5f\n', T, max(abs(pole(CLd))));
end
T  = 0.1;
Cd = Kp + Ki*tf(T, [1 -1], T) + Kd*tf([2 -2], [T T], T)    % ДПФ цифрового регулятора
% Критический период дискретизации (граница устойчивости)
f  = @(T) max(abs(pole(feedback((Kp + Ki*tf(T,[1 -1],T) + Kd*tf([2 -2],[T T],T)) ...
         *c2d(W, T, 'zoh'), 1)))) - 1;
Tcrit = fzero(f, [1.2 1.5])

% Сравнение способов дискретизации дифференциального канала при T = 0.1 c
T  = 0.1;  Wd = c2d(W, T, 'zoh');
Dt = Kd*tf([2 -2], [T T], T);                              % Тастин, s
Df = Kd*tf([2 -2], [2*Tf+T, T-2*Tf], T);                   % Тастин, s/(Tf*s+1)
Db = Kd*tf([1 -1], [T 0], T);                              % обратные разности
for D = {Dt, Df, Db}
    CLd = feedback((Kp + Ki*tf(T, [1 -1], T) + D{1})*Wd, 1);
    pd  = pole(CLd);  [~, i] = min(real(pd));
    fprintf('полюс, ближайший к z = -1: %8.4f\n', pd(i));
end
