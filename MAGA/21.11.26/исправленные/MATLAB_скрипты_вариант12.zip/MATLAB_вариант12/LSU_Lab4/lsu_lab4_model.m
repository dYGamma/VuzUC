%% Лабораторная работа №4. Демонстрация периодичности частотной
%% характеристики в Simulink (вариант 12)
% На входы двух одинаковых дискретных систем подаются синусоиды с частотами
% w0 и w0 + ws (ws = 2*pi/T). После квантования их отсчёты совпадают,
% поэтому совпадают и выходы: A(w0) = A(w0 + ws).
clear; clc; close all;
mdl = 'lab4_frequency';
a  = [0.0569 0.5917 0.3846 1];
T  = 0.5;  ws = 2*pi/T;  w0 = 1;
[numT, denT] = tfdata(c2d(tf(1, a), T, 'tustin'), 'v');

if bdIsLoaded(mdl), close_system(mdl, 0); end
if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
new_system(mdl); open_system(mdl);
try, set_param(mdl, 'HideAutomaticNames', 'off'); catch, end   % показывать имена блоков
add_block('simulink/Sources/Sine Wave', [mdl '/Sine Wave'], 'Amplitude', '1', ...
    'Frequency', 'w0', 'Position', [20 50 65 95]);
add_block('simulink/Sources/Sine Wave', [mdl '/Sine Wave1'], 'Amplitude', '1', ...
    'Frequency', 'w0 + ws', 'Position', [20 200 65 245]);
add_block('simulink/Discrete/Discrete Transfer Fcn', [mdl '/W(z)'], ...
    'Numerator', 'numT', 'Denominator', 'denT', 'SampleTime', 'T', ...
    'Position', [200 42 370 102]);
add_block('simulink/Discrete/Discrete Transfer Fcn', [mdl '/W(z)1'], ...
    'Numerator', 'numT', 'Denominator', 'denT', 'SampleTime', 'T', ...
    'Position', [200 192 370 252]);
add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', '4', ...
    'Position', [470 50 476 250]);
add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'Position', [570 125 615 175]);
add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace'], 'VariableName', 'y', ...
    'SaveFormat', 'Structure With Time', 'Position', [555 220 630 250]);
add_line(mdl, 'Sine Wave/1', 'W(z)/1', 'autorouting', 'on');
add_line(mdl, 'Sine Wave1/1', 'W(z)1/1', 'autorouting', 'on');
add_line(mdl, 'W(z)/1', 'Mux/1', 'autorouting', 'on');
add_line(mdl, 'W(z)1/1', 'Mux/2', 'autorouting', 'on');
add_line(mdl, 'Sine Wave/1', 'Mux/3', 'autorouting', 'on');     % входы — для графика
add_line(mdl, 'Sine Wave1/1', 'Mux/4', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'Scope/1', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'To Workspace/1', 'autorouting', 'on');
set_param(mdl, 'StopTime', '30', 'MaxStep', '0.005');
save_system(mdl);
try
    print(['-s' mdl], '-dpng', '-r200', 'lab4_simulink_scheme.png');
catch err
    warning('Не удалось сохранить скриншот схемы: %s', err.message);
end
out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
ys = out.get('y');  t = ys.time;  Y = ys.signals.values;
fprintf('Максимальное расхождение выходов: %.3g\n', max(abs(Y(:,1) - Y(:,2))));
figure('Name', 'Simulink: синусоиды с частотами w0 и w0 + ws', 'Position', [100 100 800 440]);
plot(t, Y(:,3), 'Color', [0.70 0.70 0.70]); hold on;
plot(t, Y(:,4), 'Color', [0.85 0.85 0.85]);
stairs(t, Y(:,1), 'LineWidth', 1.6); stairs(t, Y(:,2), '--', 'LineWidth', 1.3);
grid on; xlim([0 30]); ylim([-2.3 2.6]); xlabel('t, c'); ylabel('y(t)');
legend('sin(\omega_0 t)', 'sin((\omega_0+\omega_s) t)', 'выход при \omega_0 = 1 рад/с', ...
    'выход при \omega_0 + \omega_s', 'Location', 'northoutside', 'NumColumns', 2);
title(sprintf('Реакции дискретной системы (T = %g c) на синусоиды \\omega_0 и \\omega_0 + \\omega_s', T));
exportgraphics(gcf, 'lab4_simulink_results.png', 'Resolution', 200);
