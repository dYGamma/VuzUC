%% Лабораторная работа №4 «Частотные характеристики дискретных систем»
%% Вариант 12:  W(s) = 1/(0.0569 s^3 + 0.5917 s^2 + 0.3846 s + 1)
clear; clc; close all;
b  = 1;
a  = [0.0569 0.5917 0.3846 1];
Wc = tf(b, a)                              % непрерывная (аналоговая) система
p  = pole(Wc), damp(Wc)

%% АЧХ непрерывной системы, показатель колебательности, полоса пропускания
w  = linspace(0, 10, 100001);
Ac = abs(polyval(b, 1j*w)./polyval(a, 1j*w));     % A(w) = |W(jw)|
[Amax, i] = max(Ac);
M_c  = Amax/Ac(1)                          % показатель колебательности
wr_c = w(i)                                % резонансная частота, рад/с
wb_c = bandwidth(Wc)                       % полоса пропускания по уровню -3 дБ

%% Дискретизация и АЧХ дискретных систем (T = 0.5 и 0.1 c)
fprintf('\n метод    T     M      w_r     A(w_N)\n');
bo = bodeoptions;                          % настройки графика bode
bo.MagLowerLimMode = 'manual';  bo.MagLowerLim = -80;   % АЧХ Тастина на w_N равна 0 (-Inf дБ)
bo.Grid = 'on';
for T = [0.5 0.1]
    Wz = c2d(Wc, T, 'zoh')                 % фиксатор нулевого порядка
    Wt = c2d(Wc, T, 'tustin')              % преобразование Тастина
    wN = pi/T;  wd = linspace(0, wN, 100001);
    Az = dmag(Wz, wd);  At = dmag(Wt, wd);
    [Mz, iz] = max(Az);  [Mt, it] = max(At);
    fprintf(' ZOH    %4.2f  %6.4f  %6.4f  %8.5f\n', T, Mz/Az(1), wd(iz), Az(end));
    fprintf(' Tustin %4.2f  %6.4f  %6.4f  %8.5f\n', T, Mt/At(1), wd(it), At(end));
    figure('Name', sprintf('ЛАЧХ и ЛФЧХ, T = %g c', T));
    bodeplot(Wc, Wz, Wt, {0.1, 100}, bo);
    title(sprintf('Bode Diagram (T = %g c, \\omega_N = \\pi/T = %.3g рад/с)', T, wN));
    legend('Непрерывная', 'Дискретная (ZOH)', 'Дискретная (Тастин)', 'Location', 'southwest');
end
% Деформация частоты при преобразовании Тастина
T = 0.5;
wr_tustin_theory = 2/T*atan(wr_c*T/2)

%% Периодичность АЧХ дискретной системы (T = 0.5 c)
T  = 0.5;  ws = 2*pi/T;
Wt = c2d(Wc, T, 'tustin');  Wz = c2d(Wc, T, 'zoh');
w  = linspace(0, 3*ws, 6001);
figure('Name', 'Периодичность АЧХ');
plot(w, abs(polyval(b, 1j*w)./polyval(a, 1j*w)), w, dmag(Wt, w), w, dmag(Wz, w), '--');
grid on; hold on;
for k = 1:3, xline(k*ws, 'k:'); end                       % частоты k*ws
for k = 0:2, xline((2*k+1)*ws/2, '--', 'Color', [0.6 0.6 0.6]); end   % частоты (2k+1)*wN
xlim([0 3*ws]); ylim([0 3.2]); xlabel('\omega, рад/с'); ylabel('A(\omega)');
title(sprintf('АЧХ непрерывной и дискретной систем, T = %g c (\\omega_s = %.3f рад/с)', T, ws));
legend('Непрерывная |W(j\omega)|', 'Дискретная (Тастин)', 'Дискретная (ZOH)');

%% Зависимость периода АЧХ от частоты дискретизации
Ts = [0.25 0.5 1];
w  = linspace(0, 40, 40001);
figure('Name', 'Период АЧХ при разных T');
for i = 1:numel(Ts)
    T = Ts(i);  ws = 2*pi/T;  Wt = c2d(Wc, T, 'tustin');
    subplot(3,1,i); plot(w, dmag(Wt, w)); grid on; hold on;
    for k = 1:floor(40/ws), xline(k*ws, 'k:'); end
    xlim([0 40]); ylabel('A(\omega)');
    title(sprintf('T = %g c: \\omega_s = 2\\pi/T = %.3f рад/с', T, ws));
    % численная оценка периода: наименьший сдвиг P, при котором A(w+P) = A(w)
    P  = 1:0.001:30;  wt = linspace(0, 5, 501);  err = zeros(size(P));
    for j = 1:numel(P)
        err(j) = max(abs(dmag(Wt, wt + P(j)) - dmag(Wt, wt)));
    end
    j1 = find(err < 0.01, 1);  [~, jj] = min(err(j1:j1+100));
    fprintf('T = %4.2f c: ws = 2pi/T = %7.3f рад/с, найденный период = %7.3f рад/с\n', ...
        T, ws, P(j1+jj-1));
end
xlabel('\omega, рад/с');

%% Расчёт как в методических указаниях (Signal Processing Toolbox)
try
    T  = 0.5;  Fs = 1/T;                   % частота дискретизации, Гц
    wa = 0:0.01:3*2*pi*Fs;                 % частоты, рад/с
    h  = freqs(b, a, wa);                  % ЧХ непрерывной системы
    [bz, az] = bilinear(b, a, Fs);         % билинейное преобразование
    hz = freqz(bz, az, wa/(2*pi), Fs);     % ЧХ дискретной системы (частоты в Гц)
    figure('Name', 'freqs / bilinear / freqz');
    plot(wa, abs(h), 'r', wa, abs(hz), 'b'); grid on;
    xlabel('\omega, рад/с'); ylabel('A(\omega)'); legend('freqs', 'bilinear + freqz');
catch err
    disp(['Signal Processing Toolbox недоступен: ' err.message]);
end

%% ------------------------------------------------------------------------
function A = dmag(Wd, w)
% АЧХ дискретной системы A(w) = |W(exp(j*w*T))| на произвольной сетке частот
[num, den] = tfdata(Wd, 'v');
z = exp(1j*w*Wd.Ts);
A = abs(polyval(num, z)./polyval(den, z));
end
