%% Лабораторная работа №2 «Дискретизация систем, заданных передаточной
%% функцией». Вариант 12:  W(s) = 1/(0.1080 s^3 + 0.3401 s^2 + 0.4762 s + 1)
clear; clc; close all;

K  = 1;                                    % коэффициент усиления
a  = [0.1080 0.3401 0.4762 1];             % коэффициенты знаменателя
Wc = tf(K, a)                              % непрерывная передаточная функция
p  = pole(Wc)                              % полюса непрерывной системы
damp(Wc)                                   % собственные частоты и демпфирование
S  = stepinfo(Wc, 'SettlingTimeThreshold', 0.05)   % показатели качества
TmaxE = min(-2*real(p)./abs(p).^2)         % граница устойчивости метода Эйлера

%% Дискретные модели при T = 0.1 c
T  = 0.1;
WE = euler_c2d(Wc, T)                      % метод Эйлера: s = (z-1)/T
WT = c2d(Wc, T, 'tustin')                  % метод Тастина: s = 2/T*(z-1)/(z+1)
pE = pole(WE), pT = pole(WT)               % полюса дискретных моделей
abs_pE = abs(pE), abs_pT = abs(pT)

%% Сравнение переходных характеристик при разных T
Tlist = [0.05 0.1 0.2 0.5];
[yc, tc] = step(Wc, 30);
figure('Name', 'Переходные характеристики');
for i = 1:numel(Tlist)
    T  = Tlist(i);
    WE = euler_c2d(Wc, T);
    WT = c2d(Wc, T, 'tustin');
    [yE, tE] = step(WE, 30);
    [yT, tT] = step(WT, 30);
    subplot(2,2,i);
    plot(tc, yc, 'LineWidth', 1.3); hold on;
    stairs(tE, yE, 'LineWidth', 1.1); stairs(tT, yT, 'LineWidth', 1.1);
    grid on; xlim([0 30]); ylim([-0.5 2.5]);
    title(sprintf('T = %g c', T)); xlabel('t, c'); ylabel('y(t)');
    if i == 1, legend('Непрерывная', 'Эйлер', 'Тастин'); end
end

%% Полюса дискретных моделей
figure('Name', 'Полюса дискретных моделей');
th = linspace(0, 2*pi, 300);
for m = 1:2
    subplot(1,2,m); plot(cos(th), sin(th), 'k:', 'HandleVisibility', 'off'); hold on; grid on; axis equal;
    for T = Tlist
        if m == 1, Wd = euler_c2d(Wc, T); else, Wd = c2d(Wc, T, 'tustin'); end
        pd = pole(Wd);
        plot(real(pd), imag(pd), 'x', 'MarkerSize', 8, 'LineWidth', 1.5);
    end
    xlim([-1.4 1.6]); ylim([-1.5 1.5]); xlabel('Real Axis'); ylabel('Imaginary Axis');
    if m == 1, title('Метод Эйлера'); else, title('Метод Тастина'); end
end
legend('T = 0.05 c', 'T = 0.1 c', 'T = 0.2 c', 'T = 0.5 c', 'Location', 'southwest');

%% Ошибка дискретизации в моменты квантования
fprintf('\n    T    |z|max Эйлер  ошибка Эйлер  |z|max Тастин  ошибка Тастин\n');
for T = [0.01 0.05 0.1 0.2 0.3 0.5]
    [eE, rE] = disc_error(euler_c2d(Wc, T), Wc, T);
    [eT, rT] = disc_error(c2d(Wc, T, 'tustin'), Wc, T);
    fprintf('%6.2f  %11.4f  %12.4f  %13.4f  %13.4f\n', T, rE, eE, rT, eT);
end
Tg = 0.01:0.01:0.5;  errE = zeros(size(Tg));  errT = zeros(size(Tg));
for i = 1:numel(Tg)
    errE(i) = disc_error(euler_c2d(Wc, Tg(i)), Wc, Tg(i));
    errT(i) = disc_error(c2d(Wc, Tg(i), 'tustin'), Wc, Tg(i));
end
errE(isinf(errE)) = NaN;                   % неустойчивые модели не отображаем
figure('Name', 'Ошибка дискретизации');
plot(Tg, errE, 'o-', Tg, errT, 's-', 'MarkerSize', 3); grid on; hold on;
xline(TmaxE, 'k--', 'граница устойчивости метода Эйлера');
xlim([0 0.5]); ylim([0 1.2]); xlabel('T, c'); ylabel('max |y(kT) - y_d(k)|');
title('Максимальная ошибка дискретизации в моменты квантования');
legend('Эйлер', 'Тастин');
% Периоды дискретизации, при которых ошибка не превышает 5 %
T5_E = fzero(@(T) disc_error(euler_c2d(Wc, T), Wc, T) - 0.05, [0.005 0.03])
T5_T = fzero(@(T) disc_error(c2d(Wc, T, 'tustin'), Wc, T) - 0.05, [0.03 0.11])

%% Неустойчивость модели Эйлера при T = 0.2 и 0.5 c
figure('Name', 'Неустойчивость модели Эйлера');
plot(tc, yc, 'LineWidth', 1.3); hold on; grid on; box on;
for T = [0.2 0.5]
    [yE, tE] = step(euler_c2d(Wc, T), 30);
    stairs(tE, yE, 'LineWidth', 1.1);
end
xlim([0 30]); ylim([-6 8]); xlabel('t, c'); ylabel('y(t)');
title('Неустойчивость дискретной модели, полученной методом Эйлера');
legend('Непрерывная', 'Эйлер, T = 0.2 c', 'Эйлер, T = 0.5 c', 'Location', 'northwest');

%% ------------------------------------------------------------------------
function Wd = euler_c2d(Wc, T)
% Дискретизация методом Эйлера (прямоугольников вперёд): s = (z-1)/T.
% Числитель и знаменатель домножаются на T^n.
[num, den] = tfdata(Wc, 'v');              % векторы одинаковой длины n+1
n  = numel(den) - 1;
Nz = zeros(1, n+1);  Dz = zeros(1, n+1);
for i = 0:n
    zi = 1;
    for j = 1:i
        zi = conv(zi, [1 -1]);             % (z-1)^i
    end
    zi = [zeros(1, n-i) zi] * T^(n-i);
    Nz = Nz + num(n+1-i) * zi;             % num(n+1-i) — коэффициент при s^i
    Dz = Dz + den(n+1-i) * zi;
end
Wd = tf(Nz, Dz, T);
end

function [e, r] = disc_error(Wd, Wc, T)
% Максимальная ошибка дискретной модели в моменты t = kT (0 <= t <= 30 c)
r = max(abs(pole(Wd)));
if r >= 1
    e = Inf;  return;                      % дискретная модель неустойчива
end
t = (0:T:30)';
e = max(abs(step(Wd, t) - step(Wc, t)));
end
