%% Лабораторная работа №2. Схема сравнения непрерывной и дискретизированных
%% систем в Simulink (вариант 12)
clear; clc; close all;
mdl = 'lab2_discretization';
K = 1;  a = [0.1080 0.3401 0.4762 1];
Wc = tf(K, a);
T = 0.1;                                    % начальное значение периода
[numE, denE] = tfdata(euler_c2d(Wc, T), 'v');
[numT, denT] = tfdata(c2d(Wc, T, 'tustin'), 'v');

if bdIsLoaded(mdl), close_system(mdl, 0); end
if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
new_system(mdl); open_system(mdl);
try, set_param(mdl, 'HideAutomaticNames', 'off'); catch, end   % показывать имена блоков
add_block('simulink/Sources/Step', [mdl '/Step'], 'Time', '0', ...
    'Position', [20 165 60 205]);
add_block('simulink/Continuous/Transfer Fcn', [mdl '/Transfer Fcn'], ...
    'Numerator', '1', 'Denominator', '[0.1080 0.3401 0.4762 1]', ...
    'Position', [190 30 390 90]);
add_block('simulink/Discrete/Discrete Transfer Fcn', [mdl '/Euler'], ...
    'Numerator', 'numE', 'Denominator', 'denE', 'SampleTime', 'T', ...
    'Position', [190 150 390 210]);
add_block('simulink/Discrete/Discrete Transfer Fcn', [mdl '/Tustin'], ...
    'Numerator', 'numT', 'Denominator', 'denT', 'SampleTime', 'T', ...
    'Position', [190 270 390 330]);
add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', '3', ...
    'Position', [500 40 506 320]);
add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'Position', [600 155 645 205]);
add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace'], 'VariableName', 'y', ...
    'SaveFormat', 'Structure With Time', 'Position', [585 250 660 282]);
add_line(mdl, 'Step/1', 'Transfer Fcn/1', 'autorouting', 'on');
add_line(mdl, 'Step/1', 'Euler/1', 'autorouting', 'on');
add_line(mdl, 'Step/1', 'Tustin/1', 'autorouting', 'on');
add_line(mdl, 'Transfer Fcn/1', 'Mux/1', 'autorouting', 'on');
add_line(mdl, 'Euler/1', 'Mux/2', 'autorouting', 'on');
add_line(mdl, 'Tustin/1', 'Mux/3', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'Scope/1', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'To Workspace/1', 'autorouting', 'on');
set_param(mdl, 'StopTime', '30', 'MaxStep', '0.01');
save_system(mdl);
try
    print(['-s' mdl], '-dpng', '-r200', 'lab2_simulink_scheme.png');
catch err
    warning('Не удалось сохранить скриншот схемы: %s', err.message);
end

Tlist = [0.05 0.1 0.2 0.5];
figure('Name', 'Simulink: сравнение систем');
for i = 1:numel(Tlist)
    T = Tlist(i);
    [numE, denE] = tfdata(euler_c2d(Wc, T), 'v');
    [numT, denT] = tfdata(c2d(Wc, T, 'tustin'), 'v');
    out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
    ys = out.get('y');  t = ys.time;  Y = ys.signals.values;
    subplot(2,2,i);
    plot(t, Y(:,1), 'LineWidth', 1.3); hold on;
    plot(t, Y(:,2), 'LineWidth', 1.1); plot(t, Y(:,3), 'LineWidth', 1.1);
    grid on; xlim([0 30]); ylim([-0.5 2.5]);
    title(sprintf('T = %g c', T)); xlabel('t, c'); ylabel('y(t)');
    if i == 1, legend('Непрерывная', 'Эйлер', 'Тастин'); end
end
exportgraphics(gcf, 'lab2_simulink_results.png', 'Resolution', 200);

function Wd = euler_c2d(Wc, T)
% Дискретизация методом Эйлера: s = (z-1)/T
[num, den] = tfdata(Wc, 'v');
n  = numel(den) - 1;
Nz = zeros(1, n+1);  Dz = zeros(1, n+1);
for i = 0:n
    zi = 1;
    for j = 1:i
        zi = conv(zi, [1 -1]);
    end
    zi = [zeros(1, n-i) zi] * T^(n-i);
    Nz = Nz + num(n+1-i) * zi;
    Dz = Dz + den(n+1-i) * zi;
end
Wd = tf(Nz, Dz, T);
end
