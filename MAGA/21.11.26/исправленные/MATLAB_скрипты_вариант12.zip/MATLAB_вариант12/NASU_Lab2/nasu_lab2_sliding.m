%% Лабораторная работа №2 «Исследование скользящего режима управления»
%% Вариант 12:  x1' = x2,  x2' = 2cos(2t) + u
clear; clc; close all;

%% Задание 7.1. Скользящее управление системой 2-го порядка
% s = x2 + c*x1,  u = -c*x2 - k*sgn(s);  |f(t)| = |2cos2t| <= 2  =>  k > 2
h  = 1e-4;  tf_ = 10;  x0 = [1; 0];         % метод Эйлера с фиксированным шагом (как ode1)
f  = @(t) 2*cos(2*t);
laws = {@(x,t,c,k) -c*x(2) - k*sign(x(2) + c*x(1)),            ... sgn
        @(x,t,c,k) -c*x(2) - k*max(min((x(2) + c*x(1))/0.05, 1), -1), ... sat, Delta = 0.05
        @(x,t,c,k) -c*x(2) - f(t) - k*sign(x(2) + c*x(1))};         % с компенсацией f(t)
cases = [2 3 1; 2 1.5 1; 2 3 2; 2 0.5 3];   % [c k номер закона]
names = {'c = 2, k = 3, sgn', 'c = 2, k = 1.5, sgn', 'c = 2, k = 3, sat', 'компенсация f, k = 0.5'};
RR = cell(1, size(cases, 1));
for j = 1:size(cases, 1)
    c = cases(j,1);  k = cases(j,2);  law = laws{cases(j,3)};
    [t, X, U] = euler_sim(@(t,x) [x(2); f(t) + law(x,t,c,k)], @(t,x) law(x,t,c,k), x0, tf_, h);
    s = X(:,2) + c*X(:,1);
    RR{j} = struct('t', t, 'x1', X(:,1), 's', s, 'u', U);
    tr = t(find(abs(s) <= 1e-2, 1));
    fprintf('%-26s t_reach = %.3f c, max|s| (t>3) = %.2e, max|x1| (t>5) = %.2e\n', ...
        names{j}, tr, max(abs(s(t > 3))), max(abs(X(t > 5, 1))));
    if j == 1
        figure('Name', 'Задание 7.1: основной режим');
        subplot(3,1,1); plot(t, X, 'LineWidth', 1.3); grid on; legend('x_1', 'x_2');
        title('Скользящее управление: c = 2, k = 3, x(0) = [1; 0]'); ylabel('x_1, x_2');
        subplot(3,1,2); plot(t, s, 'LineWidth', 1.3); grid on; ylabel('s(t)');
        title('Переключающая функция s = x_2 + 2x_1');
        subplot(3,1,3); plot(t, U, 'LineWidth', 0.5); hold on; grid on;
        ua = movmean(U, 500);  m = t > 1.05 & t < 9.97;
        plot(t(m), ua(m), 'k', 'LineWidth', 1.2);
        plot(t, -2*X(:,2) - 2*cos(2*t), 'w--');
        xlabel('t, c'); ylabel('u(t)'); title('Управление u = -2x_2 - 3 sgn(s)');
        legend('u(t)', 'среднее за 0.05 c', 'u_{eq} = -2x_2 - 2cos2t');
        figure('Name', 'Дребезг');
        m = t > 4 & t < 4.005;
        subplot(1,2,1); plot(t(m), s(m)*1e3, '.-'); grid on; title('s(t)\cdot10^3 в скользящем режиме');
        subplot(1,2,2); stairs(t(m), U(m)); grid on; title('u(t): переключения с частотой шага');
    end
end
% другие режимы: k < max|f|, граничный слой, компенсация возмущения
figure('Name', 'Задание 7.1: другие режимы', 'Position', [100 100 760 780]);
ttl = {'k = 1.5 < max|f| = 2: условие скольжения нарушено', ...
       'k = 3, sat(s/\Delta), \Delta = 0.05: граничный слой', ...
       'компенсация f(t): u = -2x_2 - 2cos2t - 0.5 sgn(s)'};
for j = 2:4
    subplot(3,1,j-1);
    plot(RR{j}.t, RR{j}.u, 'Color', [0.96 0.80 0.45]); hold on;
    plot(RR{j}.t, RR{j}.x1, 'LineWidth', 1.4); plot(RR{j}.t, RR{j}.s, 'LineWidth', 1.4);
    grid on; ylim([-4 4]); title(ttl{j-1});
    legend('u', 'x_1', 's', 'Orientation', 'horizontal', 'Location', 'southeast');
end
xlabel('t, c');
% фазовые траектории
figure('Name', 'Фазовые траектории'); hold on; grid on; box on;
ics = [1 0; -1.5 1; 0.5 2; -0.5 -2; 1.5 -1];
for i = 1:size(ics, 1)
    [~, X] = euler_sim(@(t,x) [x(2); f(t) + laws{1}(x,t,2,3)], @(t,x) 0, ics(i,:)', 8, h);
    plot(X(:,1), X(:,2), 'LineWidth', 1.2); plot(ics(i,1), ics(i,2), 'ko', 'MarkerFaceColor', 'k');
end
plot([-2 2], [4 -4], 'k--'); xlim([-2 2]); ylim([-3 3]);
xlabel('x_1'); ylabel('x_2'); title('Фазовые траектории (пунктир — линия скольжения x_2 = -2x_1)');
% влияние c
figure('Name', 'Влияние c'); hold on; grid on; box on;
for c = [1 2 4]
    [t, X] = euler_sim(@(t,x) [x(2); f(t) + laws{1}(x,t,c,3)], @(t,x) 0, x0, tf_, h);
    plot(t, X(:,1), 'LineWidth', 1.3);
    fprintf('c = %d: x1(5) = %.2e\n', c, interp1(t, X(:,1), 5));
end
xlabel('t, c'); ylabel('x_1'); legend('c = 1', 'c = 2', 'c = 4'); title('Влияние наклона линии скольжения c (k = 3)');

%% Задание 7.2. Управление перевёрнутым маятником
g = 9.8;  M = 1;  m = 0.1;  l = 0.5;        % параметры маятника (М — тележка, m — стержень)
c = 2;  K = 5;  D = 0.05;                   % линия скольжения, усиление, граничный слой
den = @(x1, mm) l*(4/3*(M + mm) - mm*cos(x1).^2);
fF  = @(x, mm) (g*sin(x(1))*(M + mm) - mm*l*sin(x(1))*cos(x(1))*x(2)^2)/den(x(1), mm);
bF  = @(x, mm) cos(x(1))/den(x(1), mm);
sat = @(z) max(min(z, 1), -1);
ctrl = @(x) (-c*x(2) - fF(x, m))/bF(x, m) - K*sat((c*x(1) + x(2))/D);   % закон управления
x0 = [0.3; 0];
fprintf('При theta = 0.3 рад: f = %.3f, b = %.3f\n', fF(x0, m), bF(x0, m));
figure('Name', 'Задание 7.2: перевёрнутый маятник', 'Position', [100 100 760 780]);
for j = 1:2
    if j == 1, mo = m; dist = 0; else, mo = 2*m; dist = 1; end   % объект: номинал / неопределённость
    rhs = @(t, x) [x(2); fF(x, mo) + bF(x, mo)*ctrl(x) + dist*sin(2*t)];
    [t, X] = ode45(rhs, [0 6], x0, odeset('MaxStep', 1e-3, 'RelTol', 1e-8));
    U = zeros(size(t));  for i = 1:numel(t), U(i) = ctrl(X(i,:)'); end
    s = c*X(:,1) + X(:,2);
    fprintf('Маятник, вариант %d: theta(1) = %.4f, theta(3) = %.5f, max|u| = %.3f Н, max|s| (t>1) = %.4f\n', ...
        j, interp1(t, X(:,1), 1), interp1(t, X(:,1), 3), max(abs(U)), max(abs(s(t > 1))));
    fprintf('   s(0) = %.2f, вход в слой |s| <= D при t = %.3f c, max|theta| при t > 2 c: %.4f\n', ...
        s(1), t(find(abs(s) <= D, 1)), max(abs(X(t > 2, 1))));
    subplot(3,1,1); plot(t, X(:,1), 'LineWidth', 1.3); hold on; grid on;
    subplot(3,1,2); plot(t, s, 'LineWidth', 1.3); hold on; grid on;
    subplot(3,1,3); plot(t, U, 'LineWidth', 1.3); hold on; grid on;
end
subplot(3,1,1); ylabel('\theta, рад'); title('Угол отклонения маятника, \theta(0) = 0.3 рад');
legend('номинальная модель', 'm = 0.2 кг в объекте + возмущение sin2t');
subplot(3,1,2); ylabel('s'); title('Переключающая функция s = c\theta + d\theta/dt');
subplot(3,1,3); ylabel('u, Н'); xlabel('t, c'); title('Управляющая сила');

% фазовые траектории маятника при разных начальных условиях (номинальная модель)
figure('Name', 'Задание 7.2: фазовые траектории'); hold on; grid on; box on;
ics2 = [0.3 0; -0.5 0.5; 0.8 0.5; -0.2 -1; 0.6 -1.5];
for i = 1:size(ics2, 1)
    [~, X] = ode45(@(t, x) [x(2); fF(x, m) + bF(x, m)*ctrl(x)], [0 4], ics2(i,:)', ...
        odeset('MaxStep', 1e-3, 'RelTol', 1e-8));
    plot(X(:,1), X(:,2), 'LineWidth', 1.3);
    plot(ics2(i,1), ics2(i,2), 'ko', 'MarkerFaceColor', 'k', 'HandleVisibility', 'off');
end
plot([-1 1], [2 -2], 'k--'); xlim([-1 1]); ylim([-2.2 2.2]);
xlabel('\theta, рад'); ylabel('d\theta/dt, рад/с');
title('Фазовые траектории маятника (пунктир — линия скольжения d\theta/dt = -2\theta)');

%% ------------------------------------------------------------------------
function [t, X, U] = euler_sim(rhs, ufun, x0, tf_, h)
% Интегрирование методом Эйлера с фиксированным шагом h
n = round(tf_/h);  t = (0:n)'*h;
X = zeros(n+1, numel(x0));  U = zeros(n+1, 1);  X(1,:) = x0';
for i = 1:n
    U(i) = ufun(t(i), X(i,:)');
    X(i+1,:) = X(i,:) + h*rhs(t(i), X(i,:)')';
end
U(end) = ufun(t(end), X(end,:)');
end
