%% Лабораторная работа №2. Модели Simulink: скользящий режим (задание 7.1)
%% и перевёрнутый маятник (задание 7.2)
clear; clc; close all;
c = 2;  k = 3;                              % параметры для задания 7.1
g = 9.8;  M = 1;  m = 0.1;  mo = 0.1;  l = 0.5;  K = 5;  D = 0.05;   % задание 7.2
cfg = {'lab2_smc',      'u(2)', '2*cos(2*u(4))+u(3)', ...
       '-c*u(2)-k*sgn(u(2)+c*u(1))', [1 0], 10, 'ode1', '1e-4', 'скользящее управление, c = 2, k = 3';
       'lab2_pendulum', 'u(2)', ...
       '(g*sin(u(1))*(M+mo)-mo*l*sin(u(1))*cos(u(1))*u(2)^2+cos(u(1))*u(3))/(l*(4/3*(M+mo)-mo*cos(u(1))^2))', ...
       ['(-2*u(2)*l*(4/3*(M+m)-m*cos(u(1))^2)-(g*sin(u(1))*(M+m)-m*l*sin(u(1))*cos(u(1))*u(2)^2))' ...
        '/cos(u(1))-K*(abs((2*u(1)+u(2))/D+1)-abs((2*u(1)+u(2))/D-1))/2'], [0.3 0], 6, 'ode4', '1e-3', ...
       'перевёрнутый маятник, \theta(0) = 0.3 рад'};
for j = 1:2
    mdl = cfg{j,1};  ic = cfg{j,5};
    if bdIsLoaded(mdl), close_system(mdl, 0); end
    if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
    new_system(mdl); open_system(mdl);
    try, set_param(mdl, 'HideAutomaticNames', 'off'); catch, end   % показывать имена блоков
    add_block('simulink/Sources/Clock', [mdl '/Clock'], 'Position', [15 20 51 56]);
    add_block('simulink/User-Defined Functions/Fcn', [mdl '/Control law'], 'Expr', cfg{j,4}, ...
        'Position', [70 135 240 175]);
    add_block('simulink/Signal Routing/Mux', [mdl '/Mux1'], 'Inputs', '3', 'Position', [275 105 281 205]);
    add_block('simulink/User-Defined Functions/Fcn', [mdl '/f1'], 'Expr', cfg{j,2}, 'Position', [330 40 530 80]);
    add_block('simulink/User-Defined Functions/Fcn', [mdl '/f2'], 'Expr', cfg{j,3}, 'Position', [330 230 530 270]);
    add_block('simulink/Continuous/Integrator', [mdl '/Integrator x1'], 'InitialCondition', num2str(ic(1)), ...
        'Position', [580 40 625 80]);
    add_block('simulink/Continuous/Integrator', [mdl '/Integrator x2'], 'InitialCondition', num2str(ic(2)), ...
        'Position', [580 230 625 270]);
    add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', '2', 'Position', [690 80 696 230]);
    add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'Position', [830 130 875 180]);
    add_block('simulink/Sinks/XY Graph', [mdl '/XY Graph'], 'Position', [830 235 875 280]);
    add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace'], 'VariableName', 'xs', ...
        'SaveFormat', 'Structure With Time', 'Position', [830 40 900 70]);
    add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace1'], 'VariableName', 'us', ...
        'SaveFormat', 'Structure With Time', 'Position', [240 60 310 90]);
    L = {'f1/1','Integrator x1/1'; 'f2/1','Integrator x2/1'; 'Integrator x1/1','Mux/1';
         'Integrator x2/1','Mux/2'; 'Mux/1','Scope/1'; 'Mux/1','To Workspace/1';
         'Integrator x1/1','XY Graph/1'; 'Integrator x2/1','XY Graph/2'; 'Mux/1','Control law/1';
         'Mux/1','Mux1/1'; 'Control law/1','Mux1/2'; 'Clock/1','Mux1/3'; 'Mux1/1','f1/1';
         'Mux1/1','f2/1'; 'Control law/1','To Workspace1/1'};
    for i = 1:size(L,1), add_line(mdl, L{i,1}, L{i,2}, 'autorouting', 'on'); end
    set_param(mdl, 'StopTime', num2str(cfg{j,6}), 'SolverType', 'Fixed-step', ...
        'Solver', cfg{j,7}, 'FixedStep', cfg{j,8});
    save_system(mdl);
    try, print(['-s' mdl], '-dpng', '-r200', [mdl '_scheme.png']); catch, end
    out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
    xs = out.get('xs');  us = out.get('us');
    [tu, iu] = unique(xs.time);
    fprintf('%s: x1(1) = %.4f, x1(3) = %.5f, max|u| = %.3f\n', mdl, ...
        interp1(tu, xs.signals.values(iu,1), 1), interp1(tu, xs.signals.values(iu,1), 3), ...
        max(abs(us.signals.values)));
    figure('Name', mdl);
    subplot(2,1,1); plot(xs.time, xs.signals.values, 'LineWidth', 1.3); grid on;
    legend('x_1', 'x_2'); title(['Simulink: ' cfg{j,9}]);
    subplot(2,1,2); plot(us.time, us.signals.values); grid on; xlabel('t, c'); ylabel('u');
    exportgraphics(gcf, [mdl '_results.png'], 'Resolution', 200);
end
