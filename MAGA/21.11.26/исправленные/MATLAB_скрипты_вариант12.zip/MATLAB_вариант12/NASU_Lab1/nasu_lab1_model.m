%% Лабораторная работа №1. Модели Simulink для заданий 6.1, 6.2, 6.3
clear; clc; close all;

%% Модели заданий 6.1 и 6.2 (интеграторы + блоки Fcn)
K = 1;  k = 1;                              % K = 0 — без управления (задание 6.1)
x0 = 1;  y0 = 2;
cfg = {'lab1_task61', '-3*u(1)+2*u(1)*u(2)^2+u(3)', '-u(2)^3-u(2)', 'K*(-2*u(1)*u(2)^2)', 10;
       'lab1_task62', 'u(2)^3', 'u(3)', '-u(1)-k*u(2)', 60};
for m = 1:2
    mdl = cfg{m,1};
    if m == 2, x0 = 1; y0 = 0; end
    if bdIsLoaded(mdl), close_system(mdl, 0); end
    if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
    new_system(mdl); open_system(mdl);
    try, set_param(mdl, 'HideAutomaticNames', 'off'); catch, end   % показывать имена блоков
    add_block('simulink/User-Defined Functions/Fcn', [mdl '/Control law'], 'Expr', cfg{m,4}, ...
        'Position', [70 135 240 175]);
    add_block('simulink/Signal Routing/Mux', [mdl '/Mux1'], 'Inputs', '2', 'Position', [275 105 281 205]);
    add_block('simulink/User-Defined Functions/Fcn', [mdl '/f1'], 'Expr', cfg{m,2}, ...
        'Position', [330 40 530 80]);
    add_block('simulink/User-Defined Functions/Fcn', [mdl '/f2'], 'Expr', cfg{m,3}, ...
        'Position', [330 230 530 270]);
    add_block('simulink/Continuous/Integrator', [mdl '/Integrator x'], 'InitialCondition', 'x0', ...
        'Position', [580 40 625 80]);
    add_block('simulink/Continuous/Integrator', [mdl '/Integrator y'], 'InitialCondition', 'y0', ...
        'Position', [580 230 625 270]);
    add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', '2', 'Position', [690 80 696 230]);
    add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'Position', [830 130 875 180]);
    add_block('simulink/Sinks/XY Graph', [mdl '/XY Graph'], 'Position', [830 235 875 280]);
    add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace'], 'VariableName', 'xy', ...
        'SaveFormat', 'Structure With Time', 'Position', [830 40 900 70]);
    L = {'f1/1','Integrator x/1'; 'f2/1','Integrator y/1'; 'Integrator x/1','Mux/1';
         'Integrator y/1','Mux/2'; 'Mux/1','Scope/1'; 'Mux/1','To Workspace/1';
         'Integrator x/1','XY Graph/1'; 'Integrator y/1','XY Graph/2'; 'Mux/1','Control law/1';
         'Mux/1','Mux1/1'; 'Control law/1','Mux1/2'; 'Mux1/1','f1/1'; 'Mux1/1','f2/1'};
    for i = 1:size(L,1), add_line(mdl, L{i,1}, L{i,2}, 'autorouting', 'on'); end
    set_param(mdl, 'StopTime', num2str(cfg{m,5}), 'MaxStep', '0.01');
    save_system(mdl);
    try, print(['-s' mdl], '-dpng', '-r200', [mdl '_scheme.png']); catch, end
    out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
    r = out.get('xy');  RS{m} = r;
    figure('Name', mdl); plot(r.time, r.signals.values, 'LineWidth', 1.3); grid on;
    xlabel('t, c'); legend('x', 'y'); title(['Simulink: ' strrep(mdl, '_', '\_')]);
end

%% Модель адаптивной системы с эталонной моделью (задание 6.3)
mdl = 'lab1_mrac';
am = 1;  bm = 1;  gam = 5;
Astep = 1;  Asin = 0;  w = 0.5;             % ступенчатый вход (для синусоиды: Astep = 0, Asin = 1)
if bdIsLoaded(mdl), close_system(mdl, 0); end
if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
new_system(mdl); open_system(mdl);
try, set_param(mdl, 'HideAutomaticNames', 'off'); catch, end   % показывать имена блоков
add_block('simulink/Sources/Step', [mdl '/Step'], 'Time', '0', 'After', 'Astep', 'Position', [15 130 55 160]);
add_block('simulink/Sources/Sine Wave', [mdl '/Sine Wave'], 'Amplitude', 'Asin', 'Frequency', 'w', ...
    'Position', [15 200 55 230]);
add_block('simulink/Math Operations/Sum', [mdl '/Sum g'], 'Inputs', '++', 'Position', [90 165 110 195]);
add_block('simulink/Continuous/Transfer Fcn', [mdl '/Reference model'], 'Numerator', 'bm', ...
    'Denominator', '[1 am]', 'Position', [430 40 570 90]);
add_block('simulink/Math Operations/Product', [mdl '/Product'], 'Inputs', '2', 'Position', [230 170 264 204]);
add_block('simulink/Math Operations/Sum', [mdl '/Sum u'], 'Inputs', '+-', 'Position', [310 172 336 198]);
add_block('simulink/Continuous/Transfer Fcn', [mdl '/Plant'], 'Numerator', '[15 1]', ...
    'Denominator', '[2 0.6 1]', 'Position', [390 160 550 210]);
add_block('simulink/Math Operations/Sum', [mdl '/Sum e'], 'Inputs', '+-', 'Position', [650 172 676 198]);
add_block('simulink/Math Operations/Product', [mdl '/Product1'], 'Inputs', '2', ...
    'Orientation', 'left', 'Position', [300 250 334 284]);
add_block('simulink/Math Operations/Product', [mdl '/Product e*g'], 'Inputs', '2', ...
    'Orientation', 'left', 'Position', [560 330 594 364]);
add_block('simulink/Math Operations/Product', [mdl '/Product e*y'], 'Inputs', '2', ...
    'Orientation', 'left', 'Position', [560 400 594 434]);
add_block('simulink/Math Operations/Gain', [mdl '/-gamma'], 'Gain', '-gam', ...
    'Orientation', 'left', 'Position', [470 327 520 367]);
add_block('simulink/Math Operations/Gain', [mdl '/gamma'], 'Gain', 'gam', ...
    'Orientation', 'left', 'Position', [470 397 520 437]);
add_block('simulink/Continuous/Integrator', [mdl '/theta1'], 'Orientation', 'left', ...
    'Position', [380 325 425 369]);
add_block('simulink/Continuous/Integrator', [mdl '/theta2'], 'Orientation', 'left', ...
    'Position', [380 395 425 439]);
add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', '5', 'Position', [760 100 766 280]);
add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'Position', [820 165 865 215]);
add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace'], 'VariableName', 'res', ...
    'SaveFormat', 'Structure With Time', 'Position', [820 240 890 270]);
L = {'Step/1','Sum g/1'; 'Sine Wave/1','Sum g/2'; 'Sum g/1','Reference model/1';
     'Sum g/1','Product/1'; 'theta1/1','Product/2'; 'Product/1','Sum u/1'; 'Product1/1','Sum u/2';
     'Sum u/1','Plant/1'; 'Plant/1','Sum e/1'; 'Reference model/1','Sum e/2';
     'theta2/1','Product1/1'; 'Plant/1','Product1/2';
     'Sum e/1','Product e*g/1'; 'Sum g/1','Product e*g/2'; 'Sum e/1','Product e*y/1';
     'Plant/1','Product e*y/2'; 'Product e*g/1','-gamma/1'; 'Product e*y/1','gamma/1';
     '-gamma/1','theta1/1'; 'gamma/1','theta2/1';
     'Reference model/1','Mux/1'; 'Plant/1','Mux/2'; 'Sum e/1','Mux/3'; 'theta1/1','Mux/4';
     'theta2/1','Mux/5'; 'Mux/1','Scope/1'; 'Mux/1','To Workspace/1'};
for i = 1:size(L,1), add_line(mdl, L{i,1}, L{i,2}, 'autorouting', 'on'); end
set_param(mdl, 'StopTime', '100', 'MaxStep', '0.01');
save_system(mdl);
try, print(['-s' mdl], '-dpng', '-r200', [mdl '_scheme.png']); catch, end

% Исследование влияния gamma для ступенчатого и синусоидального входов
for in = 1:2
    if in == 1, Astep = 1; Asin = 0; else, Astep = 0; Asin = 1; end
    figure('Name', sprintf('Simulink MRAC, вход %d', in));
    gl = [0.1 1 5 20];
    for i = 1:numel(gl)
        gam = gl(i);
        out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
        r = out.get('res');  t = r.time;  R = r.signals.values;
        fprintf('Simulink MRAC, вход %d, gamma = %4.1f: max|e| = %.4f, theta1(100) = %.4f, theta2(100) = %.4f\n', ...
            in, gam, max(abs(R(:,3))), R(end,4), R(end,5));
        if gam == 5, RM{in} = R;  TM{in} = t; end
        subplot(4,1,i); plot(t, R(:,1), 'k--', t, R(:,2), 'LineWidth', 1.2); grid on;
        title(sprintf('\\gamma = %g, max|e| = %.3f', gam, max(abs(R(:,3)))));
        ylabel('y, y_m');
    end
    xlabel('t, c');
    exportgraphics(gcf, sprintf('lab1_mrac_input%d.png', in), 'Resolution', 200);
end

%% Сводный рисунок результатов моделирования в Simulink
figure('Name', 'Simulink: сводка', 'Position', [100 100 900 620]);
subplot(2,2,1); plot(RS{1}.time, RS{1}.signals.values, 'LineWidth', 1.3); grid on;
title('Задание 6.1: x(0) = 1, y(0) = 2, u = -2xy^2'); legend('x', 'y'); xlabel('t, c');
subplot(2,2,2); plot(RS{2}.time, RS{2}.signals.values, 'LineWidth', 1.3); grid on;
title('Задание 6.2: x(0) = 1, y(0) = 0, u = -x - y'); legend('x', 'y'); xlabel('t, c');
subplot(2,2,3); plot(TM{1}, RM{1}(:,1), 'k--', TM{1}, RM{1}(:,2), 'LineWidth', 1.2); grid on;
title('Задание 6.3: ступенчатый вход, \gamma = 5'); legend('y_m', 'y'); xlabel('t, c');
subplot(2,2,4); plot(TM{2}, RM{2}(:,1), 'k--', TM{2}, RM{2}(:,2), 'LineWidth', 1.2); grid on;
title('Задание 6.3: вход sin 0.5t, \gamma = 5'); legend('y_m', 'y'); xlabel('t, c');
exportgraphics(gcf, 'lab1_simulink_summary.png', 'Resolution', 200);
