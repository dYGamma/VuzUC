%% Лабораторная работа №1 «Использование функций Ляпунова при
%% проектировании адаптивной системы». Вариант 12
clear; clc; close all;
opts = odeset('RelTol', 1e-8, 'AbsTol', 1e-10, 'MaxStep', 0.01);

%% Задание 6.1:  x' = -3x + 2xy^2 + u,  y' = -y^3 - y,  V = (x^2 + y^2)/2
try                                         % проверка производной V (Symbolic Math Toolbox)
    syms x y real
    V = (x^2 + y^2)/2;
    dV_u0 = simplify(diff(V,x)*(-3*x + 2*x*y^2) + diff(V,y)*(-y^3 - y))
    u = -2*x*y^2;                           % синтезированное управление
    dV    = simplify(diff(V,x)*(-3*x + 2*x*y^2 + u) + diff(V,y)*(-y^3 - y))
catch
    disp('Symbolic Math Toolbox недоступен');
end
f61 = @(t, s, K) [-3*s(1) + 2*s(1)*s(2)^2 + K*(-2*s(1)*s(2)^2);  -s(2)^3 - s(2)];
ics = [1 2; -2 1.5; 2 -2; -1 -2.5; 0.5 3];
figure('Name', 'Задание 6.1: фазовые траектории');
for K = [0 1]
    subplot(1,2,K+1); hold on; grid on; box on;
    for i = 1:size(ics,1)
        [~, s] = ode45(@(t,s) f61(t,s,K), [0 10], ics(i,:)', opts);
        plot(s(:,1), s(:,2), 'LineWidth', 1.3); plot(ics(i,1), ics(i,2), 'ko', 'MarkerFaceColor', 'k');
    end
    xlim([-6 6]); ylim([-3 3.2]); xlabel('x'); ylabel('y');
    if K == 0, title('Фазовые траектории: u = 0'); else, title('Фазовые траектории: u = -2xy^2'); end
end
figure('Name', 'Задание 6.1: переходные процессы');
for K = [0 1]
    [t, s] = ode45(@(t,s) f61(t,s,K), [0 6], [3; 1.5], opts);
    Vt = (s(:,1).^2 + s(:,2).^2)/2;
    if K == 0, ls = '--'; else, ls = '-'; end
    subplot(2,1,1); plot(t, s(:,1), ls, t, s(:,2), ls, 'LineWidth', 1.3); hold on; grid on;
    subplot(2,1,2); plot(t, Vt, ls, 'LineWidth', 1.3); hold on; grid on;
    fprintf('K = %d: max x = %.4f, x(1) = %.4f, V(0) = %.3f, max V = %.3f\n', K, max(s(:,1)), ...
        interp1(t, s(:,1), 1), Vt(1), max(Vt));
end
subplot(2,1,1); title('Переходные процессы при x(0) = 3, y(0) = 1.5'); ylabel('x, y');
legend('x, u = 0', 'y, u = 0', 'x, u = -2xy^2', 'y, u = -2xy^2');
subplot(2,1,2); title('Функция Ляпунова V = (x^2 + y^2)/2'); ylabel('V'); xlabel('t, c');
legend('u = 0', 'u = -2xy^2');

%% Задание 6.2:  x' = y^3,  y' = u,  V = x^2/2 + y^4/4
try
    syms x y real
    V = x^2/2 + y^4/4;
    u = -x - y;
    dV = simplify(diff(V,x)*y^3 + diff(V,y)*u)       % = -y^4
catch
end
k = 1;
f62 = @(t, s) [s(2)^3; -s(1) - k*s(2)];
ics2 = [1 0; -1.5 1; 2 -1.5; -1 -1.5; 0.5 1.8];
figure('Name', 'Задание 6.2: фазовые траектории'); hold on; grid on; box on;
for i = 1:size(ics2,1)
    [~, s] = ode45(f62, [0 60], ics2(i,:)', opts);
    plot(s(:,1), s(:,2), 'LineWidth', 1.3); plot(ics2(i,1), ics2(i,2), 'ko', 'MarkerFaceColor', 'k');
end
xlim([-2.2 2.2]); ylim([-2 2]); xlabel('x'); ylabel('y'); title('Фазовые траектории при u = -x - y');
[t, s] = ode45(f62, [0 100], [1; 0], opts);
Vt = s(:,1).^2/2 + s(:,2).^4/4;
fprintf('dV/dt <= 0 на всей траектории: %d\n', all(diff(Vt) <= 1e-12));
fprintf('x(10) = %.4f, x(20) = %.4f, x(50) = %.4f, x(100) = %.4f\n', interp1(t, s(:,1), [10 20 50 100]));
figure('Name', 'Задание 6.2: переходные процессы');
subplot(2,1,1); plot(t, s(:,1), t, s(:,2), t, -s(:,1) - k*s(:,2), 'LineWidth', 1.3); grid on;
xlim([0 40]); legend('x(t)', 'y(t)', 'u(t)'); title('Переходные процессы при x(0) = 1, y(0) = 0, u = -x - y');
subplot(2,1,2); loglog(t(2:end), abs(s(2:end,1)), t(2:end), Vt(2:end), 'LineWidth', 1.3); hold on;
tt = logspace(0.5, 2, 50); loglog(tt, 1./sqrt(2*tt), 'k--'); grid on;
xlim([1 100]); ylim([1e-3 1.5]); xlabel('t, c'); legend('|x(t)|', 'V(t)', '1/sqrt(2t)');
title('Медленное (неэкспоненциальное) затухание x(t)');

%% Задание 6.3: адаптивная система с эталонной моделью
% Объект W2(s) = (15s + 1)/(2s^2 + 0.6s + 1), эталонная модель bm/(s + am)
[Ap, Bp, Cp] = tf2ss([15 1], [2 0.6 1]);
W2 = tf([15 1], [2 0.6 1]), p2 = pole(W2), z2 = zero(W2)
am = 1;  bm = 1;
gams = [0.1 1 5 20];
inputs = {@(t) 1, @(t) sin(0.5*t)};  names = {'ступенчатое', 'синусоидальное sin(0.5t)'};
for m = 1:2
    g = inputs{m};
    figure('Name', ['Задание 6.3: ' names{m}], 'Position', [100 100 760 820]);
    fprintf('\nВход: %s\n gamma   max|e|   y_max   rms e (80..100 c)   theta1   theta2   min theta2\n', names{m});
    R = cell(1, numel(gams));
    for i = 1:numel(gams)
        gam = gams(i);
        [t, Z] = ode45(@(t,z) mrac_rhs(t, z, Ap, Bp, Cp, am, bm, gam, g), [0 100], zeros(5,1), opts);
        y = (Cp*Z(:,1:2)')';  ym = Z(:,3);  e = y - ym;
        idx = t >= 80;
        fprintf('%6.1f  %7.4f  %6.3f  %10.4f  %14.4f  %8.4f  %9.4f\n', gam, max(abs(e)), max(y), ...
            sqrt(mean(e(idx).^2)), Z(end,4), Z(end,5), min(Z(:,5)));
        R{i} = struct('t', t, 'e', e, 'th1', Z(:,4), 'th2', Z(:,5));
        subplot(4,1,i); plot(t, ym, 'k--', t, y, 'LineWidth', 1.2); grid on;
        title(sprintf('\\gamma = %g', gam)); ylabel('y, y_m'); xlim([0 100]);
        if i == 1, legend('эталонная модель y_m', 'объект y'); end
    end
    xlabel('t, c');
    % ошибка адаптации и настраиваемые параметры
    figure('Name', ['Задание 6.3: ошибка и параметры, ' names{m}], 'Position', [100 100 760 620]);
    subplot(2,1,1); hold on; grid on; box on;
    for i = 1:numel(gams), plot(R{i}.t, R{i}.e, 'LineWidth', 1); end
    xlim([0 100]); ylabel('e = y - y_m'); title('Ошибка адаптации');
    legend(compose('\\gamma = %g', gams), 'Orientation', 'horizontal');
    subplot(2,1,2); hold on; grid on; box on;  co = get(gca, 'ColorOrder');
    for i = 1:numel(gams)
        plot(R{i}.t, R{i}.th1, '-', 'Color', co(i,:), 'LineWidth', 1.1);
        plot(R{i}.t, R{i}.th2, '--', 'Color', co(i,:), 'LineWidth', 1.1, 'HandleVisibility', 'off');
    end
    xlim([0 100]); xlabel('t, c'); ylabel('\theta_1, \theta_2');
    title('Настраиваемые параметры (сплошные — \theta_1, пунктир — \theta_2)');
    legend(compose('\\gamma = %g', gams), 'Orientation', 'horizontal');
end

%% Длительное моделирование (600 c)
[t, Z] = ode45(@(t,z) mrac_rhs(t, z, Ap, Bp, Cp, am, bm, 0.1, inputs{1}), [0 600], zeros(5,1), opts);
e = (Cp*Z(:,1:2)')' - Z(:,3);
fprintf('\nСтупенчатый вход, gamma = 0.1, 600 c: theta1 = %.3f, theta2 = %.3f\n', Z(end,4), Z(end,5));
fprintf('  |e| > 0.01 последний раз при t = %.1f c, |e| > 0.001 — при t = %.1f c\n', ...
    t(find(abs(e) > 0.01, 1, 'last')), t(find(abs(e) > 0.001, 1, 'last')));
[t, Z] = ode45(@(t,z) mrac_rhs(t, z, Ap, Bp, Cp, am, bm, 20, inputs{2}), [0 600], zeros(5,1), opts);
fprintf('Синусоидальный вход, gamma = 20, 600 c: theta1 = %.2f, theta2 = %.2f\n', Z(end,4), Z(end,5));

%% Параметры, дающие точное совпадение y и y_m на частоте 0.5 рад/с
w0 = 0.5;  s0 = 1j*w0;
cc = polyval([2 0.6 1], s0)/polyval([15 1], s0);        % a(jw)/b(jw)
th1x = imag(cc)/w0;  th2x = th1x - real(cc);            % th1*(jw + 1) - th2 = a/b
pcl = roots([2, 0.6 + 15*th2x, 1 + th2x]);              % полюса контура с theta2 = th2x
fprintf('theta1 = %.3f, theta2 = %.3f, полюса замкнутого контура: %.3f +- %.3fj\n', ...
    th1x, th2x, real(pcl(1)), abs(imag(pcl(1))));

%% ------------------------------------------------------------------------
function dz = mrac_rhs(t, z, Ap, Bp, Cp, am, bm, gam, g)
% z = [x_объекта (2); ym; theta1; theta2]
xp = z(1:2);  ym = z(3);  th1 = z(4);  th2 = z(5);
y  = Cp*xp;  gt = g(t);
u  = th1*gt - th2*y;                        % закон управления (6.1)
e  = y - ym;                                % ошибка адаптации
dz = [Ap*xp + Bp*u;                         % объект
      -am*ym + bm*gt;                       % эталонная модель
      -gam*e*gt;                            % закон адаптации (6.2)
       gam*e*y];
end
