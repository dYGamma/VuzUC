MATLAB-скрипты к лабораторным работам (вариант 12)
=================================================

Все скрипты проверены в MATLAB Online R2026b (Update 2): каждая работа запущена,
рисунки и схемы в отчётах получены этими скриптами.

Папки:
  LSU_Lab1 ... LSU_Lab6   — «Локальные системы управления», ЛР 1–6
  NASU_Lab1 ... NASU_Lab3 — «Нелинейные и адаптивные системы управления», ЛР 1–3

В каждой папке два файла:
  *_<тема>.m  — расчётная программа (листинг — Приложение А отчёта):
                все вычисления, таблицы и графики отчёта;
  *_model.m   — скрипт, который сам собирает модель Simulink (.slx), запускает её
                и сохраняет в PNG схему (*_scheme.png) и графики результатов
                (листинг — Приложение Б отчёта).

Вспомогательные функции (в корне папки):
  run_lab.m — запуск одной работы с журналом (*_log.txt) и сохранением всех рисунков
              в PNG: run_lab('LSU_Lab1', 'lsu_lab1_filters')
  run_all.m — запуск всех 18 скриптов подряд: run_all   (около 20–30 мин)
  В run_lab.m путь к папке задан строкой root = '/MATLAB Drive/maga' —
  при другом расположении папки исправьте её.

Как запустить в MATLAB Online:
  1. Откройте https://matlab.mathworks.com и войдите в аккаунт.
  2. Загрузите папку в MATLAB Drive (Files -> Upload Folders / Upload Files).
  3. Сделайте папку работы текущей (двойной щелчок в панели Files).
  4. Откройте .m-файл и нажмите Run (или наберите имя скрипта в Command Window).
  5. После *_model.m в папке появятся модель .slx и PNG-файлы схемы и результатов.

Нужны пакеты: MATLAB, Simulink, Control System Toolbox
(Symbolic Math Toolbox и Signal Processing Toolbox — только для проверочных
фрагментов, при их отсутствии скрипты продолжат работу).

Возможные сбои MATLAB Online (не ошибки скриптов):
  * «Invalid argument at position 1. Metadata not yet loaded, try again» при вызове
    step, bode, pzmap и т. п. — сбой загрузки ресурсов в сеансе. Перезапустите
    MATLAB Online либо выполните один раз:
      matlab.internal.regfwk.enableResources(fullfile(matlabroot, ...
          'toolbox','shared','controllib','graphics','charts'))
  * «Transport endpoint is not connected» при сохранении файлов — MATLAB Drive
    отключился (обычно после повторного запроса входа). Перезапустите сеанс.
