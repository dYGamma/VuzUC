%% Лабораторная работа №5. Модель Simulink: непрерывный объект, блок
%% Discrete State-Space и структурная схема дискретной модели (рис. 6.1)
clear; clc; close all;
mdl = 'lab5_statespace';
A = [-34 -54 -17; 20 30.5 9.4; -5.9 -7.9 -2.3];
B = [0.228; -0.127; 0.038];
C = [21000 63000 84000];  D = 0;
T = 0.4;  N = 4;
Ad = eye(3);  term = eye(3);  S = eye(3)*T;  termS = eye(3)*T;
for i = 1:N                                % ряд матричной экспоненты
    term = term*(A*T)/i;  Ad = Ad + term;
    if i < N, termS = termS*(A*T)/(i+1);  S = S + termS; end
end
Bd = S*B;

if bdIsLoaded(mdl), close_system(mdl, 0); end
if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
new_system(mdl); open_system(mdl);
try, set_param(mdl, 'HideAutomaticNames', 'off'); catch, end   % показывать имена блоков
add_block('simulink/Sources/Step', [mdl '/Step'], 'Time', '0', 'Position', [20 195 60 235]);
add_block('simulink/Continuous/State-Space', [mdl '/State-Space'], 'A', 'A', 'B', 'B', ...
    'C', 'C', 'D', 'D', 'Position', [185 30 350 85]);
add_block('simulink/Discrete/Discrete State-Space', [mdl '/Discrete State-Space'], ...
    'A', 'Ad', 'B', 'Bd', 'C', 'C', 'D', 'D', 'SampleTime', 'T', 'Position', [185 140 350 195]);
% структурная схема x(k+1) = Ad*x(k) + Bd*u(k), y(k) = C*x(k)
add_block('simulink/Discrete/Zero-Order Hold', [mdl '/ZOH'], 'SampleTime', 'T', ...
    'Position', [110 300 145 340]);
add_block('simulink/Math Operations/Gain', [mdl '/Gain Bd'], 'Gain', 'Bd', ...
    'Multiplication', 'Matrix(K*u)', 'Position', [170 300 225 340]);
add_block('simulink/Math Operations/Sum', [mdl '/Sum'], 'IconShape', 'rectangular', ...
    'Inputs', '++', 'Position', [270 300 300 340]);
add_block('simulink/Discrete/Unit Delay', [mdl '/Unit Delay'], 'SampleTime', 'T', ...
    'InitialCondition', 'zeros(3,1)', 'Position', [350 297 400 343]);
add_block('simulink/Math Operations/Gain', [mdl '/Gain C'], 'Gain', 'C', ...
    'Multiplication', 'Matrix(K*u)', 'Position', [455 300 510 340]);
add_block('simulink/Math Operations/Gain', [mdl '/Gain Ad'], 'Gain', 'Ad', ...
    'Multiplication', 'Matrix(K*u)', 'Orientation', 'left', 'Position', [330 395 385 435]);
add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', '3', 'Position', [590 40 596 360]);
add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'Position', [680 175 725 225]);
add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace'], 'VariableName', 'y', ...
    'SaveFormat', 'Structure With Time', 'Position', [665 270 740 300]);
add_line(mdl, 'Step/1', 'State-Space/1', 'autorouting', 'on');
add_line(mdl, 'Step/1', 'Discrete State-Space/1', 'autorouting', 'on');
add_line(mdl, 'Step/1', 'ZOH/1', 'autorouting', 'on');
add_line(mdl, 'ZOH/1', 'Gain Bd/1', 'autorouting', 'on');
add_line(mdl, 'Gain Bd/1', 'Sum/1', 'autorouting', 'on');
add_line(mdl, 'Sum/1', 'Unit Delay/1', 'autorouting', 'on');
add_line(mdl, 'Unit Delay/1', 'Gain C/1', 'autorouting', 'on');
add_line(mdl, 'Unit Delay/1', 'Gain Ad/1', 'autorouting', 'on');
add_line(mdl, 'Gain Ad/1', 'Sum/2', 'autorouting', 'on');
add_line(mdl, 'State-Space/1', 'Mux/1', 'autorouting', 'on');
add_line(mdl, 'Discrete State-Space/1', 'Mux/2', 'autorouting', 'on');
add_line(mdl, 'Gain C/1', 'Mux/3', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'Scope/1', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'To Workspace/1', 'autorouting', 'on');
set_param(mdl, 'StopTime', '60', 'MaxStep', '0.01');
save_system(mdl);
try
    print(['-s' mdl], '-dpng', '-r200', 'lab5_simulink_scheme.png');
catch err
    warning('Не удалось сохранить скриншот схемы: %s', err.message);
end
out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
ys = out.get('y');  t = ys.time;  Y = ys.signals.values;
yinf = dcgain(ss(A, B, C, D));
fprintf('Максимальная ошибка дискретной модели: %.2f %%\n', ...
    max(abs(Y(:,1) - Y(:,2)))/abs(yinf)*100);
fprintf('Расхождение блока Discrete State-Space и структурной схемы: %.3g\n', ...
    max(abs(Y(:,2) - Y(:,3))));
figure('Name', 'Simulink: переходные процессы');
plot(t, Y(:,1), 'LineWidth', 1.3); hold on; plot(t, Y(:,2), 'LineWidth', 1.1);
plot(t, Y(:,3), '--', 'LineWidth', 1.1); grid on; xlabel('t, c'); ylabel('y(t)');
legend('State-Space (непрерывный)', 'Discrete State-Space', 'Структурная схема', ...
    'Location', 'southeast');
title(sprintf('Сравнение переходных процессов, T = %g c', T));
exportgraphics(gcf, 'lab5_simulink_results.png', 'Resolution', 200);
