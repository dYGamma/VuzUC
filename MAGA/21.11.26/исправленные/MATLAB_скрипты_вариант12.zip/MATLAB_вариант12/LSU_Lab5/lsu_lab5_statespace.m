%% Лабораторная работа №5 «Исследование дискретных систем в пространстве
%% состояний». Вариант 12
clear; clc; close all;
A = [-34   -54   -17
      20   30.5   9.4
     -5.9  -7.9  -2.3];
B = [0.228; -0.127; 0.038];
C = [21000 63000 84000];
D = 0;
sysc = ss(A, B, C, D);                     % непрерывный объект

%% Анализ непрерывной системы
lam  = eig(A)                              % собственные числа (полюса)
abs_lam = abs(lam)                         % модули собственных чисел
[V, ~] = eig(A);
cond_V = cond(V), norm_A = norm(A)         % обусловленность собственных векторов, ||A||
Wc   = tf(sysc)                            % передаточная функция
z0   = zero(sysc)                          % нули (правый нуль -> неминимально-фазовый)
yinf = dcgain(sysc)                        % установившееся значение
S    = stepinfo(sysc, 'SettlingTimeThreshold', 0.05)
CB   = C*B                                 % начальная скорость y'(0+)

%% Дискретизация методом матричной экспоненты (ряд, как в методичке, N = 4)
T = 0.4;  N = 4;
[Ad, Bd] = mexp_series(A, B, T, N)
sysd  = ss(Ad, Bd, C, D, T);               % дискретная модель
lam_d = eig(Ad), abs_lam_d = abs(lam_d)
stable_d = isstable(sysd)
sysx = c2d(sysc, T, 'zoh');                % точная матричная экспонента (expm)
Adx = sysx.A, Bdx = sysx.B, lam_x = eig(Adx)
[Ad1, ~] = mexp_series(A, B, T, 1);        % ряд с N = 1 (метод Эйлера)
lam_N1 = eig(Ad1), abs_lam_N1 = abs(lam_N1)

figure('Name', 'Собственные числа', 'Position', [100 100 820 380]);
subplot(1,2,1); plot(real(lam), imag(lam), 'x', 'MarkerSize', 10, 'LineWidth', 2);
hold on; grid on; xline(0, 'k');
xlim([-4 1]); ylim([-5 5]); xlabel('Real Axis'); ylabel('Imaginary Axis');
title('Собственные числа A (плоскость s)');
subplot(1,2,2); th = linspace(0, 2*pi, 300);
plot(cos(th), sin(th), 'k:', 'HandleVisibility', 'off'); hold on; grid on;
plot(real(lam_x), imag(lam_x), 'o', real(lam_d), imag(lam_d), 'x', ...
     real(lam_N1), imag(lam_N1), '+', 'MarkerSize', 9, 'LineWidth', 1.5);
axis equal; xlim([-1.8 1.8]); ylim([-1.8 1.8]); xlabel('Real Axis'); ylabel('Imaginary Axis');
title(sprintf('Собственные числа A_d, T = %g c', T));
legend('expm', 'N = 4', 'N = 1', 'Location', 'southwest');

%% Сравнение переходных процессов
tfin = 60;
t  = linspace(0, tfin, 200001)';
yc = step(sysc, t);
figure('Name', 'Переходные процессы');
Tlist = [0.1 0.4 0.5];
for i = 1:numel(Tlist)
    [Adi, Bdi] = mexp_series(A, B, Tlist(i), 4);
    [yd, tk] = step(ss(Adi, Bdi, C, D, Tlist(i)), tfin);
    d = disc_err(A, B, C, Tlist(i), 4, t, yc, yinf);
    subplot(3,1,i); plot(t, yc, 'LineWidth', 1.3); hold on;
    stairs(tk, yd, 'LineWidth', 1.1); grid on; xlim([0 tfin]); ylim([-500 9500]);
    title(sprintf('T = %g c: максимальная ошибка %.2f %%', Tlist(i), d)); ylabel('y(t)');
    legend('Непрерывная', sprintf('Дискретная (N = 4), T = %g c', Tlist(i)), ...
        'Location', 'southeast');
end
xlabel('t, c');

%% Начальный участок переходных процессов
[ymin, imin] = min(yc);
fprintf('Минимум переходной характеристики: y = %.2f при t = %.3f c\n', ymin, t(imin));
figure('Name', 'Начальный участок', 'Position', [100 100 820 380]);
for sp = 1:2
    subplot(1,2,sp); plot(t, yc, 'LineWidth', 1.3); hold on; grid on;
    for Ti = [0.1 0.4]
        [Adi, Bdi] = mexp_series(A, B, Ti, 4);
        [yd, tk] = step(ss(Adi, Bdi, C, D, Ti), 4);
        stairs(tk, yd, 'LineWidth', 1.1);
    end
    xlabel('t, c'); ylabel('y(t)');
    if sp == 1
        xlim([0 3]); ylim([-100 2500]); title('Начальный участок');
        legend('Непрерывная', 'T = 0.1 c', 'T = 0.4 c', 'Location', 'northwest');
    else
        xlim([0 0.8]); ylim([-30 60]); title('Участок 0–0.8 c (отклонение вниз)');
    end
end

%% Ошибка дискретизации в зависимости от T (N = 4 и точная экспонента)
Tg = 0.02:0.005:0.60;
d4 = zeros(size(Tg));  dk4 = d4;  dx = d4;
for i = 1:numel(Tg)
    [d4(i), dk4(i)] = disc_err(A, B, C, Tg(i), 4, t, yc, yinf);
    dx(i) = disc_err(A, B, C, Tg(i), Inf, t, yc, yinf);
end
T5_N4    = Tg(find(d4 <= 5, 1, 'last'))      % наибольший T с ошибкой <= 5 % (N = 4)
T5_exact = Tg(find(dx <= 5, 1, 'last'))      % то же для точной экспоненты
d4(isinf(d4)) = NaN;  dk4(isinf(dk4)) = NaN;
figure('Name', 'Ошибка от T');
plot(Tg, d4, 'o-', Tg, dx, 's-', Tg, dk4, '^-', 'MarkerSize', 3); grid on; hold on;
yline(5, 'k--'); xline(T5_N4, 'k:'); xlim([0 0.61]); ylim([0 8]); xlabel('T, c'); ylabel('\delta, %');
title('Максимальная ошибка дискретизации в зависимости от T');
legend('N = 4, полная ошибка', 'expm, полная ошибка', 'N = 4, ошибка в моменты kT', ...
    'Location', 'northwest');
fprintf('\n   T     rho(Ad)   dk, %%    d, %%   (N = 4)   d (expm), %%\n');
for Ti = [0.05 0.1 0.2 0.3 0.4 0.45 0.5 0.55]
    [d, dk, rho] = disc_err(A, B, C, Ti, 4, t, yc, yinf);
    dxe = disc_err(A, B, C, Ti, Inf, t, yc, yinf);
    fprintf('%5.2f  %8.5f  %7.4f  %7.3f  %10.3f\n', Ti, rho, dk, d, dxe);
end

%% Влияние числа членов ряда матричной экспоненты
for Ti = [0.1 0.4]
    fprintf('\nT = %g c\n   N    rho(Ad)    dk, %%      d, %%\n', Ti);
    for Ni = [1 2 3 4 5 6 8 Inf]
        [d, dk, rho] = disc_err(A, B, C, Ti, Ni, t, yc, yinf);
        fprintf('%4g  %9.5f  %9.2e  %8.3f\n', Ni, rho, dk, d);
    end
end
% граница устойчивости приближённой модели для разных N
for Ni = 1:6
    for Ti = 0.001:0.001:3
        [Adi, ~] = mexp_series(A, B, Ti, Ni);
        if max(abs(eig(Adi))) >= 1
            fprintf('N = %d: модель неустойчива при T >= %.3f c\n', Ni, Ti);  break;
        end
    end
end
figure('Name', 'Ошибка от числа членов ряда');
Ns = [1 2 3 4 5 6 8];  hold on;
for Ti = [0.1 0.2 0.4]
    dk = zeros(size(Ns));
    for j = 1:numel(Ns)
        [~, dk(j)] = disc_err(A, B, C, Ti, Ns(j), t, yc, yinf);
    end
    dk(isinf(dk)) = NaN;
    semilogy(Ns, dk, 'o-');
end
set(gca, 'YScale', 'log'); grid on; box on; xticks(Ns);
xlabel('Число членов ряда N (наибольшая степень AT)'); ylabel('\delta_k, % (в моменты kT)');
title('Ошибка аппроксимации матричной экспоненты');
legend('T = 0.1 c', 'T = 0.2 c', 'T = 0.4 c');

%% ------------------------------------------------------------------------
function [Ad, Bd] = mexp_series(A, B, T, N)
% Приближённая матричная экспонента:
% Ad = I + AT + (AT)^2/2! + ... + (AT)^N/N!
% Bd = (IT + AT^2/2! + ... + A^(N-1)T^N/N!)*B
n = size(A, 1);
Ad = eye(n);  term = eye(n);
S  = eye(n)*T;  termS = eye(n)*T;
for i = 1:N
    term = term*(A*T)/i;
    Ad = Ad + term;
    if i < N
        termS = termS*(A*T)/(i+1);
        S = S + termS;
    end
end
Bd = S*B;
end

function [d, dk, rho] = disc_err(A, B, C, T, N, t, yc, yinf)
% d  — максимальная ошибка с учётом фиксации выхода между отсчётами, %
% dk — максимальная ошибка в моменты t = kT, %;  rho — спектральный радиус Ad
% N = Inf — точная матричная экспонента
if isinf(N)
    sd = c2d(ss(A, B, C, 0), T, 'zoh');  Ad = sd.A;  Bd = sd.B;
else
    [Ad, Bd] = mexp_series(A, B, T, N);
end
rho = max(abs(eig(Ad)));
if rho >= 1
    d = Inf;  dk = Inf;  return;           % дискретная модель неустойчива
end
n  = floor(t(end)/T + 1e-9);
yd = zeros(n+1, 1);  x = zeros(size(B));
for i = 1:n+1
    yd(i) = C*x;  x = Ad*x + Bd;
end
yk  = step(ss(A, B, C, 0), (0:n)'*T);     % точные значения y(kT) непрерывного объекта
dk  = max(abs(yk - yd))/abs(yinf)*100;
idx = min(floor(t/T + 1e-9) + 1, n+1);     % номер отсчёта, действующего в момент t
% полная ошибка: по плотной сетке и в конце каждого интервала (t -> (k+1)T - 0)
d   = max([abs(yc - yd(idx)); abs(yk(2:end) - yd(1:end-1))])/abs(yinf)*100;
end
