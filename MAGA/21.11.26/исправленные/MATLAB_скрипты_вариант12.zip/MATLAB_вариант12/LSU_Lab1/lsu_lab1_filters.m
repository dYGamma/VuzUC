%% Лабораторная работа №1 «Цифровые фильтры». Вариант 12
% Разностное уравнение фильтра: y(k) = 0.75*y(k-1) + 0.35*u(k-1)
clear; clc; close all;

a1 = 0.75;                 % коэффициент при y(k-1)
b1 = 0.35;                 % коэффициент при u(k-1)
N  = 20;                   % число отсчётов
u  = ones(N,1);            % единичное ступенчатое воздействие

%% 1) Расчёт выхода фильтра в цикле
y = zeros(N,1);            % y(1) соответствует моменту k = 0
for k = 2:N
    y(k) = a1*y(k-1) + b1*u(k-1);
end

%% 2) Расчёт с помощью функции filter
num = [0 b1];              % числитель:   0 + 0.35*z^-1
den = [1 -a1];             % знаменатель: 1 - 0.75*z^-1
y1  = filter(num, den, u);

%% 3) Расчёт с помощью дискретной передаточной функции (tf, step)
T  = 1;                    % период дискретизации, с
W  = tf(b1, [1 -a1], T)    % W(z) = 0.35/(z - 0.75)
n  = (0:N-1)';
y2 = step(W, n*T);

%% Сравнение результатов
yan = b1/(1-a1)*(1 - a1.^n);            % аналитическое решение
disp(table(n, y, y1, y2, yan, 'VariableNames', ...
    {'k', 'y_for', 'y_filter', 'y_step', 'y_analyt'}))
fprintf('max|for - filter| = %.3g\n', max(abs(y - y1)));
fprintf('max|for - step|   = %.3g\n', max(abs(y - y2)));
fprintf('max|for - analyt| = %.3g\n', max(abs(y - yan)));
yinf = dcgain(W)                        % установившееся значение W(1)
p    = pole(W)                          % полюс передаточной функции
k5   = ceil(log(0.05)/log(a1))          % число тактов до входа в 5%-ю зону

figure('Name', 'Сравнение методов расчёта', 'Position', [100 100 640 720]);
subplot(3,1,1); plot(n, y, '*'); grid on; xlim([0 20]); ylim([0 1.6]);
title('Расчёт в цикле for'); xlabel('k'); ylabel('y(k)');
subplot(3,1,2); plot(n, y1, 'd'); grid on; xlim([0 20]); ylim([0 1.6]);
title('Функция filter'); xlabel('k'); ylabel('y(k)');
[y3, t3] = step(W, 24);                 % переходная характеристика объекта tf
subplot(3,1,3); stairs(t3, y3, 'LineWidth', 1.2); grid on; xlim([0 24]); ylim([0 1.6]);
title('Step Response (функция tf, step)'); xlabel('t, c'); ylabel('y(t)');

%% Переходные процессы при различных периодах дискретизации
Ts = [0.1 0.5 1 2];
figure('Name', 'Влияние периода дискретизации'); hold on; grid on; box on;
for i = 1:numel(Ts)
    Wi = tf(b1, [1 -a1], Ts(i));
    [yi, ti] = step(Wi, 25);
    stairs(ti, yi, 'LineWidth', 1.3);
    fprintf('T = %4.1f c: t_п(5%%) = %5.2f c\n', Ts(i), k5*Ts(i));
end
yline(yinf, 'k--');
xlim([0 25]); ylim([0 1.55]); xlabel('t, c'); ylabel('y(t)');
title('Переходные процессы фильтра при разных T');
legend('T = 0.1 c', 'T = 0.5 c', 'T = 1 c', 'T = 2 c', 'Location', 'southeast');

%% Те же процессы в функции номера такта k
figure('Name', 'Процессы в функции номера такта'); hold on; grid on; box on;
mk = {'o', 's', '^', 'x'};  Yk = zeros(21, numel(Ts));
for i = 1:numel(Ts)
    Yk(:,i) = step(tf(b1, [1 -a1], Ts(i)), (0:20)'*Ts(i));
    plot(0:20, Yk(:,i), mk{i}, 'LineWidth', 1.1, 'MarkerSize', 7);
end
xlim([0 20]); ylim([0 1.55]); xlabel('Номер такта k'); ylabel('y(k)');
title('Те же процессы в функции номера такта k');
legend('T = 0.1 c', 'T = 0.5 c', 'T = 1 c', 'T = 2 c', 'Location', 'southeast');
fprintf('Наибольшее расхождение y(k) при разных T: %.3g\n', max(max(abs(Yk - Yk(:,1)))));
