%% Лабораторная работа №1. Сборка и моделирование схемы Simulink (вариант 12)
% Скрипт создаёт модель lab1_filter.slx с тремя реализациями фильтра
% y(k) = 0.75*y(k-1) + 0.35*u(k-1), запускает её при разных T
% и сохраняет скриншот схемы и графики в PNG.
clear; clc; close all;
mdl = 'lab1_filter';
T = 1;                                    % период дискретизации (параметр блоков)
if bdIsLoaded(mdl), close_system(mdl, 0); end
if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
new_system(mdl); open_system(mdl);
try, set_param(mdl, 'HideAutomaticNames', 'off'); catch, end   % показывать имена блоков

% Источник ступенчатого сигнала
add_block('simulink/Sources/Step', [mdl '/Step'], 'Time', '0', 'Before', '0', ...
    'After', '1', 'SampleTime', 'T', 'Position', [20 190 60 230]);
% 1) Блок Discrete Filter (полиномы по степеням z^-1)
add_block('simulink/Discrete/Discrete Filter', [mdl '/Discrete Filter'], ...
    'Numerator', '[0 0.35]', 'Denominator', '[1 -0.75]', 'SampleTime', 'T', ...
    'Position', [190 25 340 80]);
% 2) Блок Discrete Transfer Fcn (полиномы по степеням z)
add_block('simulink/Discrete/Discrete Transfer Fcn', [mdl '/Discrete Transfer Fcn'], ...
    'Numerator', '[0.35]', 'Denominator', '[1 -0.75]', 'SampleTime', 'T', ...
    'Position', [190 115 340 170]);
% 3) Разностное уравнение на элементарных блоках
add_block('simulink/Discrete/Unit Delay', [mdl '/Unit Delay'], 'SampleTime', 'T', ...
    'Position', [190 300 235 345]);
add_block('simulink/Math Operations/Gain', [mdl '/Gain b'], 'Gain', '0.35', ...
    'Position', [280 302 330 342]);
add_block('simulink/Math Operations/Sum', [mdl '/Sum'], 'IconShape', 'rectangular', ...
    'Inputs', '++', 'Position', [380 302 410 342]);
add_block('simulink/Discrete/Unit Delay', [mdl '/Unit Delay1'], 'SampleTime', 'T', ...
    'Orientation', 'left', 'Position', [500 395 545 440]);
add_block('simulink/Math Operations/Gain', [mdl '/Gain a'], 'Gain', '0.75', ...
    'Orientation', 'left', 'Position', [420 397 470 437]);
% Регистрация результатов
add_block('simulink/Signal Routing/Mux', [mdl '/Mux'], 'Inputs', '3', ...
    'Position', [600 60 606 360]);
add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'Position', [680 185 725 235]);
add_block('simulink/Sinks/To Workspace', [mdl '/To Workspace'], 'VariableName', 'y', ...
    'SaveFormat', 'Structure With Time', 'Position', [660 270 735 302]);

% Соединения
add_line(mdl, 'Step/1', 'Discrete Filter/1', 'autorouting', 'on');
add_line(mdl, 'Step/1', 'Discrete Transfer Fcn/1', 'autorouting', 'on');
add_line(mdl, 'Step/1', 'Unit Delay/1', 'autorouting', 'on');
add_line(mdl, 'Unit Delay/1', 'Gain b/1', 'autorouting', 'on');
add_line(mdl, 'Gain b/1', 'Sum/1', 'autorouting', 'on');
add_line(mdl, 'Sum/1', 'Unit Delay1/1', 'autorouting', 'on');
add_line(mdl, 'Unit Delay1/1', 'Gain a/1', 'autorouting', 'on');
add_line(mdl, 'Gain a/1', 'Sum/2', 'autorouting', 'on');
add_line(mdl, 'Discrete Filter/1', 'Mux/1', 'autorouting', 'on');
add_line(mdl, 'Discrete Transfer Fcn/1', 'Mux/2', 'autorouting', 'on');
add_line(mdl, 'Sum/1', 'Mux/3', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'Scope/1', 'autorouting', 'on');
add_line(mdl, 'Mux/1', 'To Workspace/1', 'autorouting', 'on');
set_param(mdl, 'StopTime', '25');
save_system(mdl);
try
    print(['-s' mdl], '-dpng', '-r200', 'lab1_simulink_scheme.png');   % скриншот схемы
catch err
    warning('Не удалось сохранить скриншот схемы: %s', err.message);
end

%% Моделирование при разных периодах дискретизации
Ts = [0.1 0.5 1 2];
figure('Name', 'Simulink: переходные процессы при разных T');
for i = 1:numel(Ts)
    T = Ts(i);                            % новое значение параметра блоков
    out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
    ys  = out.get('y');
    t   = ys.time;  Y = ys.signals.values;
    subplot(2,2,i);
    stairs(t, Y(:,1), 'LineWidth', 1.5); hold on;
    stairs(t, Y(:,2), '--', 'LineWidth', 1.2);
    stairs(t, Y(:,3), ':', 'LineWidth', 1.2);
    grid on; xlim([0 25]); ylim([0 1.5]);
    title(sprintf('T = %g c', T)); xlabel('t, c'); ylabel('y(t)');
    legend('Discrete Filter', 'Discrete Transfer Fcn', 'Unit Delay + Gain', ...
        'Location', 'southeast');
    fprintf('T = %4.1f c: расхождение реализаций = %.3g\n', T, ...
        max(max(abs(Y - Y(:,1)))));
end
exportgraphics(gcf, 'lab1_simulink_results.png', 'Resolution', 200);
